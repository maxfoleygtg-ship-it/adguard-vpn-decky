"""
AdGuard VPN — Decky Loader backend (v1.1.1).

  * run_action(action) — включить/выключить VPN ТОЛЬКО через встроенный скрипт
    adguard-vpn.sh (в папке плагина): slovakia/germany/sweden/kazakhstan/off или
    `connect "<локация>"`. Запуск от имени пользователя, в его сессии systemd --user
    (иначе setpriv/runuser), отсоединённо; плагин сам adguardvpn-cli connect не вызывает.
  * get_status(), get_pings()/get_locations(), account_info(), check_setup() — ТОЛЬКО
    ЧТЕНИЕ: adguardvpn-cli status / list-locations / license от имени пользователя.
  * login_start()/login_poll() — `adguardvpn-cli login` в псевдотерминале: ссылка и QR-код
    (вход через браузер, device code). Пароль плагин не спрашивает и не видит.

1.0.9: режим «Через Steam» (ярлык в библиотеке, shortcuts.vdf, RunGame) удалён.
1.1.0: автоподключение при запуске Decky, переподключение при обрыве (сторож в фоне),
«самая быстрая» (connect -f), IP через VPN, проверка обновления CLI, срок подписки.
1.1.1: ГЛАВНОЕ — Decky 3.3+ (Python 3.14) не содержит модулей pty/termios: `import pty` в начале
файла ронял весь бэкенд при загрузке → панель вечно «Проверка…», вход не нажимался, Журнал пуст.
Теперь только stdlib из сборки Decky (os.openpty), жёсткие тайм-ауты с убийством группы процессов,
отмена подключения, вход прерывает зависшие команды, подробный Журнал.

Журнал: ~/homebrew/logs/adguard-vpn/backend.log, вывод скрипта: script.log, вход: login.log
"""

import asyncio
import json
import logging
import os
import pwd
import re
import shutil
import subprocess
import threading
import time
import urllib.request
import signal
import tempfile

import decky

CLI_PATH = "/usr/local/bin/adguardvpn-cli"
CLI_NAME = "adguardvpn-cli"
# Сколько ждём ответа adguardvpn-cli. На медленной/фильтруемой сети CLI при КАЖДОМ запуске
# сначала скачивает свой конфиг (DoH-серверы, s3/googleapis) и только потом отвечает:
# проверено на 1.8.3 — без доступа к серверам AdGuard любая команда идёт 30–40 сек.
# Поэтому 15 сек. (1.0.7) было мало → «Нет ответа». Теперь 75 сек.
STATUS_TIMEOUT = 75
SLOW_CLI_SECONDS = 10        # дольше — пишем в лог и показываем подсказку «медленная сеть»
USER_SESSION_LAUNCH = True   # встроенный скрипт — через systemd --user пользователя (как Steam)
SCRIPT_TIMEOUT = 90          # сек. ждём завершения скрипта спокойно
SCRIPT_HARD_TIMEOUT = 150    # сек. — дальше скрипт (и его дочерние процессы) убиваем
PROGRESS_EVERY = 30          # сек. — запись «connect идёт N с…» в Журнал

LOG = decky.logger
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07|\r")

# ---------- пользователь и окружение ----------


def _strip_ansi(text: str) -> str:
    return ANSI_RE.sub("", text or "")


_USER_CACHE = {"ts": 0.0, "name": None, "how": ""}


def _owner_name(path: str):
    try:
        uid = os.stat(path).st_uid
        if uid == 0:
            return None
        return pwd.getpwuid(uid).pw_name
    except Exception:
        return None


def _steam_owner():
    """Владелец процесса steam / gamescope (тот, кто сидит в игровом режиме)."""
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            with open(f"/proc/{pid}/comm") as f:
                if f.read().strip() not in ("steam", "gamescope", "gamescope-session", "steamwebhelper"):
                    continue
            uid = os.stat(f"/proc/{pid}").st_uid
            if uid >= 1000:
                return pwd.getpwuid(uid).pw_name
        except Exception:
            continue
    return None


def _candidate_users():
    yield "decky.DECKY_USER", getattr(decky, "DECKY_USER", None)
    yield "env DECKY_USER", os.environ.get("DECKY_USER")
    yield "env SUDO_USER", os.environ.get("SUDO_USER")
    for attr in ("DECKY_USER_HOME", "DECKY_HOME"):
        v = getattr(decky, attr, None)
        if v:
            yield f"owner {attr}", _owner_name(v)
    plugin_dir = getattr(decky, "DECKY_PLUGIN_DIR", None) or os.path.dirname(os.path.abspath(__file__))
    homebrew = os.path.dirname(os.path.dirname(plugin_dir))           # ~/homebrew/plugins/<x> → ~/homebrew
    yield "owner ~/homebrew", _owner_name(homebrew)
    yield "owner ~", _owner_name(os.path.dirname(homebrew))
    yield "steam process", _steam_owner()
    try:
        yield "uid 1000", pwd.getpwuid(1000).pw_name
    except KeyError:
        pass
    for base in ("/home", "/var/home"):
        try:
            for d in sorted(os.listdir(base)):
                yield f"{base}/*", _owner_name(os.path.join(base, d))
        except Exception:
            pass


def _target_user():
    """
    Обычный пользователь, от имени которого работает adguardvpn-cli (его логин хранится в ~).
    1.0.7 подставлял жёстко «MiniGamingPC», если Decky не сообщил имя — на чужом устройстве это
    давало запуск CLI от root с несуществующим HOME. Теперь ищем по нескольким признакам,
    а если не нашли — None (CLI от root НЕ запускаем).
    """
    c = _USER_CACHE
    if c["name"] and time.monotonic() - c["ts"] < 300:
        return c["name"]
    for how, name in _candidate_users():
        if not name or name == "root":
            continue
        try:
            if pwd.getpwnam(name).pw_uid == 0:
                continue
        except KeyError:
            continue
        if name != c["name"]:
            LOG.info(f"пользователь: {name} (определён по: {how})")
        c.update(ts=time.monotonic(), name=name, how=how)
        return name
    c.update(ts=time.monotonic(), name=None, how="")
    return None


def _pw():
    name = _target_user()
    if not name:
        return None
    try:
        return pwd.getpwnam(name)
    except KeyError:
        return None


def _user_home() -> str:
    pw = _pw()
    if pw:
        return pw.pw_dir
    return getattr(decky, "DECKY_USER_HOME", None) or "/nonexistent"


SESSION_VARS = ("DISPLAY", "WAYLAND_DISPLAY", "XAUTHORITY", "XDG_RUNTIME_DIR",
                "DBUS_SESSION_BUS_ADDRESS", "XDG_SESSION_TYPE", "XDG_CURRENT_DESKTOP",
                "XDG_SESSION_DESKTOP", "XDG_DATA_DIRS", "XDG_CONFIG_DIRS", "LANG")


def _session_env_from_procs() -> dict:
    """Берём DISPLAY/WAYLAND/DBUS и т.п. у процессов сессии пользователя (steam, gamescope, plasma)."""
    pw = _pw()
    if not pw:
        return {}
    preferred = ("steam", "gamescope", "plasmashell", "kwin_wayland", "kwin_x11", "steamwebhelper")
    best = {}
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            if os.stat(f"/proc/{pid}").st_uid != pw.pw_uid:
                continue
            with open(f"/proc/{pid}/comm") as f:
                comm = f.read().strip()
            if comm not in preferred:
                continue
            with open(f"/proc/{pid}/environ", "rb") as f:
                raw = f.read().split(b"\0")
        except Exception:
            continue
        env = {}
        for item in raw:
            k, _, v = item.decode("utf-8", "replace").partition("=")
            if k in SESSION_VARS and v:
                env[k] = v
        if len(env) > len(best):
            best = env
    return best


def _user_env(extra_path: str = "") -> dict:
    """Чистое окружение пользователя (без LD_LIBRARY_PATH/PYTHON* от Decky)."""
    pw = _pw()
    user = _target_user() or "nobody"
    env = {
        "HOME": _user_home(),
        "USER": user,
        "LOGNAME": user,
        "SHELL": (pw.pw_shell if pw else "") or "/bin/bash",
        "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "LANG": "ru_RU.UTF-8",
    }
    home = env["HOME"]
    env["XDG_CONFIG_HOME"] = os.path.join(home, ".config")
    env["XDG_DATA_HOME"] = os.path.join(home, ".local/share")
    env["XDG_CACHE_HOME"] = os.path.join(home, ".cache")
    env["XDG_STATE_HOME"] = os.path.join(home, ".local/state")
    # sudo без правила NOPASSWD не должен открывать скрытое окно пароля в игровом режиме — сразу ошибка
    env["SUDO_ASKPASS"] = "/bin/false"
    if pw:
        env["XDG_RUNTIME_DIR"] = f"/run/user/{pw.pw_uid}"
        if os.path.exists(f"/run/user/{pw.pw_uid}/bus"):
            env["DBUS_SESSION_BUS_ADDRESS"] = f"unix:path=/run/user/{pw.pw_uid}/bus"
    env.update({k: v for k, v in _session_env_from_procs().items()
                if k not in ("XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME")})
    if extra_path:
        env["PATH"] = extra_path + ":" + env["PATH"]
    return env


def _as_user(cmd: list) -> list:
    """Запуск от имени пользователя БЕЗ sudo: setpriv (util-linux) или runuser."""
    pw = _pw()
    if os.geteuid() != 0 or not pw:
        return cmd
    setpriv = shutil.which("setpriv")
    if setpriv:
        return [setpriv, f"--reuid={pw.pw_uid}", f"--regid={pw.pw_gid}", "--init-groups", "--"] + cmd
    runuser = shutil.which("runuser")
    if runuser:
        return [runuser, "-u", pw.pw_name, "--"] + cmd
    return cmd


def _log_dir() -> str:
    path = getattr(decky, "DECKY_PLUGIN_LOG_DIR", None) or "/tmp/adguard-vpn"
    os.makedirs(path, exist_ok=True)
    return path


def _runtime_dir() -> str:
    path = getattr(decky, "DECKY_PLUGIN_RUNTIME_DIR", None) or "/tmp/adguard-vpn-runtime"
    os.makedirs(path, exist_ok=True)
    return path


def _setup_file_log() -> None:
    try:
        path = os.path.join(_log_dir(), "backend.log")
        if any(getattr(h, "baseFilename", None) == path for h in LOG.handlers):
            return
        if os.path.exists(path) and os.path.getsize(path) > 1_000_000:
            os.replace(path, path + ".old")
        h = logging.FileHandler(path, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        LOG.addHandler(h)
        LOG.setLevel(logging.INFO)
    except Exception as e:
        LOG.warning(f"backend.log недоступен: {e}")


# ---------- статус (только чтение) ----------

STATUS_LINE_RE = re.compile(
    r"\b(?P<state>connected|waiting to reconnect|waiting to connect|reconnecting)\s+to\s+"
    r"(?P<loc>.+?)\s+in\s+(?P<mode>\S+)\s+mode", re.IGNORECASE)
ACTIVE_RE = re.compile(r"\bvpn (is )?active\b", re.IGNORECASE)      # код 10: "VPN active, but status unavailable"
STARTING_RE = re.compile(r"\bvpn is starting\b", re.IGNORECASE)
DISCONNECTED_RE = re.compile(r"\b(vpn is disconnected|disconnected|not connected)\b", re.IGNORECASE)
AUTH_RE = re.compile(r"(not logged in|please log in|log in first|login required|adguardvpn-cli login|"
                     r"unauthori[sz]ed|session (has )?expired)", re.IGNORECASE)
LICENSE_RE = re.compile(r"(subscription (has )?expired|no (active )?subscription|license (has )?expired|"
                        r"limit (is |has been )?(reached|exceeded))", re.IGNORECASE)

LOCATION_HINTS = {
    "Slovakia": ["slovakia", "bratislava", "kosice", "(sk)"],
    "Germany": ["germany", "frankfurt", "berlin", "munich", "dusseldorf", "hamburg", "(de)"],
    "Sweden": ["sweden", "stockholm", "gothenburg", "malmo", "(se)"],
    "Kazakhstan": ["kazakhstan", "astana", "almaty", "(kz)"],
}


def _detect_location(text: str):
    low = (text or "").lower()
    for loc, hints in LOCATION_HINTS.items():
        if any(h in low for h in hints):
            return loc
    return None


def _parse_status(raw: str, code: int) -> dict:
    text = _strip_ansi(raw).strip()
    state, loc_text = "unknown", ""
    m = STATUS_LINE_RE.search(text)
    if m:
        state = "connected" if m.group("state").lower() == "connected" else "reconnecting"
        loc_text = m.group("loc").strip()
    elif code == 10 or ACTIVE_RE.search(text):
        state = "connected"          # туннель есть, просто status не смог прочитать подробности
    elif STARTING_RE.search(text):
        state = "connecting"
    elif DISCONNECTED_RE.search(text):
        state = "disconnected"
    error = None
    if state != "connected":
        if AUTH_RE.search(text):
            error = "not_logged_in"
        elif LICENSE_RE.search(text):
            error = "no_subscription"
    return {"state": state, "connected": state == "connected", "location": _detect_location(loc_text),
            "location_text": loc_text, "raw": text, "code": code, "error": error}


# ---------- поиск скриптов ----------

# ---------- встроенный скрипт ----------

def _bundled_script() -> str:
    base = getattr(decky, "DECKY_PLUGIN_DIR", None) or os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, "adguard-vpn.sh")


BUNDLED_MAPPING = {"Slovakia": "slovakia", "Germany": "germany", "Sweden": "sweden",
                   "Kazakhstan": "kazakhstan", "off": "off"}
LEGACY_CHOICES = set(BUNDLED_MAPPING.values()) | {"status", "fastest"}
# Любая локация: "loc:<город, страна или ISO>" -> adguard-vpn.sh connect "<...>"
LOC_TARGET_RE = re.compile(r"^[^\W_][\w .,'()\-]{0,63}$")


def _location_target(choice: str):
    """Возвращает безопасное имя локации из "loc:..." или None."""
    if not choice.startswith("loc:"):
        return None
    t = choice[4:].strip()
    return t if LOC_TARGET_RE.match(t) else None


# ---------- вход в аккаунт ----------

# CLI может дать ссылку не на auth.adguard.io, а на зеркало со случайным доменом
# (например https://ljsfb.qr4xvfan.surf/device_code?user_code=HRLJ-XNTP) — берём любую https-ссылку,
# предпочитая ту, где есть device_code / user_code.
LOGIN_URL_RE = re.compile(r"https?://[^\s<>\"'`]+", re.IGNORECASE)


def _extract_login_url(text: str) -> str:
    urls = [u.rstrip(".,;:)]}'\"") for u in LOGIN_URL_RE.findall(_strip_ansi(text or ""))]
    urls = [u for u in urls if re.match(r"https?://[\w.-]+\.[a-z]{2,}", u, re.IGNORECASE)]
    for u in urls:
        if re.search(r"device_code|user_code", u, re.IGNORECASE):
            return u
    https = [u for u in urls if u.lower().startswith("https://")]
    return (https or urls or [""])[0]
LOGIN_CODE_RE = re.compile(r"user_code=([A-Z0-9-]{4,})|\bcode[^A-Za-z0-9]{1,5}([A-Z0-9]{4}-[A-Z0-9]{4})\b", re.IGNORECASE)
LOGIN_TTL_RE = re.compile(r"available for\s+(\d+)\s+seconds", re.IGNORECASE)
LOGIN_OK_RE = re.compile(r"successfully logged in|logged in as|you are already logged in|already logged in", re.IGNORECASE)
LOGIN_FAIL_RE = re.compile(r"(failed[^\r\n]*|error[^\r\n]*|expired[^\r\n]*|cancel+ed[^\r\n]*|timed? ?out[^\r\n]*)", re.IGNORECASE)


def _cli_path():
    if os.path.exists(CLI_PATH):
        return CLI_PATH
    for p in ("/opt/adguardvpn_cli/adguardvpn-cli", os.path.join(_user_home(), ".local/bin/adguardvpn-cli")):
        if os.path.exists(p):
            return p
    return shutil.which(CLI_NAME)


# Вопросы первого запуска (согласие на отчёты об ошибках / статистику). 1.8.3 их в status/license/
# list-locations не задаёт, но на случай другой версии: stdin=/dev/null + автонастройка «нет».
CONSENT_RE = re.compile(r"(crash report|send (anonymous )?(usage|statistics|crash)|usage data|telemetry|"
                        r"may we|would you like|do you (want|agree)|\[y/n\]|\(y/n\)|\[Y/n\]|\[y/N\])",
                        re.IGNORECASE)
_CONSENT_FIXED = {"done": False}


def _app_log_tail(n: int = 6) -> str:
    """Последние важные строки ~/.local/share/adguardvpn-cli/app.log (для диагностики «нет ответа»)."""
    path = os.path.join(_user_home(), ".local/share/adguardvpn-cli/app.log")
    try:
        with open(path, "rb") as f:
            f.seek(max(0, os.path.getsize(path) - 64 * 1024))
            lines = f.read().decode("utf-8", "replace").splitlines()
        keep = [ln for ln in lines if re.search(r"WARN|ERROR|BackendConfig|DoH", ln)]
        return "\n".join(x[:220] for x in keep[-n:])
    except Exception:
        return ""


def _fix_consent() -> bool:
    """Один раз отвечаем «нет» на вопросы первого запуска без интерактива."""
    if _CONSENT_FIXED["done"]:
        return False
    _CONSENT_FIXED["done"] = True
    r = _run_cli_raw(["config", "set-crash-reporting", "off"], STATUS_TIMEOUT)
    LOG.info(f"первый запуск: config set-crash-reporting off -> {r['code']}: {r['output'][:200]!r}")
    return r["code"] == 0


_CLI_PROCS = set()          # живые процессы adguardvpn-cli (status/license/list-locations…)


def _kill_group(proc, grace: float = 2.0) -> None:
    """Убить процесс и всю его группу (start_new_session=True → pgid == pid)."""
    if proc is None or proc.poll() is not None:
        return
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(proc.pid, sig)
        except Exception:
            try:
                proc.send_signal(sig)
            except Exception:
                pass
        try:
            proc.wait(timeout=grace)
            return
        except Exception:
            continue


def _kill_all_cli(reason: str) -> int:
    n = 0
    for p in list(_CLI_PROCS):
        if p.poll() is None:
            _kill_group(p, 1.0)
            n += 1
    if n:
        LOG.warning(f"остановлено команд adguardvpn-cli: {n} ({reason})")
    return n


def _run_cli_raw(args: list, timeout: int) -> dict:
    cli = _cli_path()
    if not cli:
        return {"code": -2, "output": f"Не найден {CLI_PATH}", "timeout": False}
    if os.geteuid() == 0 and not _pw():
        LOG.error("не удалось определить пользователя — adguardvpn-cli от root не запускаем")
        return {"code": -4, "output": "Не удалось определить пользователя (DECKY_USER)", "timeout": False,
                "error": "user_unknown"}
    cmd = _as_user([cli] + args)
    env = _user_env()
    t0 = time.monotonic()
    # Вывод — во временный ФАЙЛ, не в pipe: если CLI оставит фоновый процесс (демон туннеля),
    # тот унаследует pipe, и чтение «до конца» зависло бы навсегда.
    try:
        out_f = tempfile.TemporaryFile(mode="w+b")
    except Exception as e:
        return {"code": -3, "output": f"Ошибка: {e}", "timeout": False}
    with out_f:
        try:
            proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=out_f, stderr=subprocess.STDOUT,
                                    env=env, cwd="/", start_new_session=True, close_fds=True)
        except Exception as e:
            return {"code": -3, "output": f"Ошибка: {e}", "timeout": False}
        _CLI_PROCS.add(proc)
        timed_out = False
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            _kill_group(proc)
        finally:
            _CLI_PROCS.discard(proc)
        out_f.seek(0)
        text = _strip_ansi(out_f.read(200_000).decode("utf-8", "replace")).strip()
    dt = time.monotonic() - t0
    if timed_out:
        LOG.error(f"adguardvpn-cli {' '.join(args)}: нет ответа за {timeout} сек. — убит; "
                  f"user={env.get('USER')} HOME={env.get('HOME')} cmd={cmd!r}\napp.log:\n{_app_log_tail()}")
        return {"code": -1, "output": f"нет ответа за {timeout} сек.", "timeout": True}
    if proc.returncode in (-signal.SIGTERM, -signal.SIGKILL) and dt < timeout:
        return {"code": -5, "output": "команда прервана (вход/отмена)", "timeout": False, "error": "killed"}
    if dt > SLOW_CLI_SECONDS:
        LOG.warning(f"adguardvpn-cli {' '.join(args)}: ответ через {dt:.0f} сек. (медленная сеть?)")
    return {"code": proc.returncode, "output": text, "timeout": False, "seconds": round(dt, 1)}


def _run_cli_sync(args: list, timeout: int) -> dict:
    r = _run_cli_raw(args, timeout)
    if not r["timeout"] and r["code"] not in (0, -2, -4) and CONSENT_RE.search(r["output"]) \
            and not AUTH_RE.search(r["output"]):
        LOG.warning(f"adguardvpn-cli {' '.join(args)}: похоже на вопрос первого запуска: {r['output'][:300]!r}")
        if _fix_consent():
            r = _run_cli_raw(args, timeout)
        if CONSENT_RE.search(r["output"]) and not AUTH_RE.search(r["output"]):
            r["error"] = "not_configured"
    return r


# Один запуск CLI на команду: если такая же команда уже идёт — ждём её результат,
# а не запускаем ещё один процесс (статус опрашивается каждые 4 сек., а на медленной
# сети одна команда может идти 30+ сек.).
_INFLIGHT = {}


async def _cli_once(args: list, timeout: int) -> dict:
    key = " ".join(args)
    fut = _INFLIGHT.get(key)
    if fut is not None and not fut.done():
        return await asyncio.shield(fut)
    fut = asyncio.ensure_future(asyncio.to_thread(_run_cli_sync, args, timeout))
    _INFLIGHT[key] = fut
    try:
        return await asyncio.shield(fut)
    finally:
        if _INFLIGHT.get(key) is fut and fut.done():
            _INFLIGHT.pop(key, None)


# ---------- пинг локаций (adguardvpn-cli list-locations, только чтение) ----------
#
# Формат вывода (заголовок жирный через ANSI):
#   ISO   COUNTRY              CITY                           PING ESTIMATE
#   SK    Slovakia             Bratislava                     44
#   DE    Germany              Frankfurt                      43
#   DE    Germany              Berlin                         46
#   SE    Sweden               Stockholm                      62
#   You can connect to a location by running ...

LOCATION_ROW_RE = re.compile(r"^(?P<iso>[A-Z]{2})\s{2,}(?P<country>.+?)\s{2,}(?P<city>.+?)\s{2,}(?P<ping>\d+)\s*$")
PING_COUNTRIES = {"Slovakia": "SK", "Germany": "DE", "Sweden": "SE", "Kazakhstan": "KZ"}
PING_CACHE_SECONDS = 45
PING_TIMEOUT = 90


def _parse_locations(text: str) -> list:
    rows = []
    for line in _strip_ansi(text).splitlines():
        m = LOCATION_ROW_RE.match(line.rstrip())
        if m:
            rows.append({"iso": m.group("iso"), "country": m.group("country").strip(),
                         "city": m.group("city").strip(), "ping": int(m.group("ping"))})
    return rows


def _pings_from_rows(rows: list) -> dict:
    """Для каждой нашей страны — город с наименьшим пингом и пинги всех её городов."""
    result = {}
    for loc, iso in PING_COUNTRIES.items():
        cities = [r for r in rows if r["iso"] == iso or r["country"].lower() == loc.lower()]
        if not cities:
            continue
        best = min(cities, key=lambda r: r["ping"])
        result[loc] = {"ping": best["ping"], "city": best["city"],
                       "cities": {r["city"].upper(): r["ping"] for r in cities}}
    return result


def _fallback_locations() -> list:
    base = getattr(decky, "DECKY_PLUGIN_DIR", None) or os.path.dirname(os.path.abspath(__file__))
    try:
        with open(os.path.join(base, "locations_fallback.json"), encoding="utf-8") as f:
            return [dict(r, ping=None) for r in json.load(f)["locations"]]
    except Exception as e:
        LOG.warning(f"locations_fallback.json: {e}")
        return []


def _favorites_path() -> str:
    d = getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", None) or "/tmp/adguard-vpn-settings"
    return os.path.join(d, "favorites.json")


def _load_favorites() -> list:
    try:
        with open(_favorites_path(), encoding="utf-8") as f:
            v = json.load(f).get("favorites", [])
            return [k for k in v if isinstance(k, str)]
    except FileNotFoundError:
        return []
    except Exception as e:
        LOG.warning(f"favorites.json: {e}")
        return []


def _save_favorites(favs: list) -> None:
    path = _favorites_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"favorites": favs}, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


# ---------- запуск в сессии пользователя ----------

_USER_SESSION_CACHE = {"ts": 0.0, "ok": False}


def _user_session_ok() -> bool:
    """Доступен ли systemd --user менеджер пользователя (проверка раз в 5 минут)."""
    if not USER_SESSION_LAUNCH or os.geteuid() != 0 or not shutil.which("systemd-run"):
        return False
    pw = _pw()
    if not pw or not os.path.exists(f"/run/user/{pw.pw_uid}/bus"):
        return False
    if time.monotonic() - _USER_SESSION_CACHE["ts"] < 300:
        return _USER_SESSION_CACHE["ok"]
    try:
        r = subprocess.run(["systemd-run", f"--machine={pw.pw_name}@.host", "--user", "--quiet",
                            "--collect", "--wait", "--", "/bin/true"],
                           stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=15, env={"PATH": "/usr/bin:/bin:/usr/sbin:/sbin"})
        ok = r.returncode == 0
        if not ok:
            LOG.warning(f"systemd --user недоступен: {r.stdout.strip()[:300]!r}")
    except Exception as e:
        LOG.warning(f"systemd --user недоступен: {e}")
        ok = False
    _USER_SESSION_CACHE.update(ts=time.monotonic(), ok=ok)
    return ok


# ---------- запуск скрипта ----------

# ---------- настройки и состояние (1.1.0) ----------

DEFAULT_SETTINGS = {"autoconnect": False, "autoconnect_action": "last", "autoconnect_label": "",
                    "reconnect": False}
WATCHDOG_INTERVAL = 30          # сек. между проверками статуса сторожем
RECONNECT_DELAYS = (10, 30, 60)  # пауза перед 1-й, 2-й, 3-й попыткой; потом сдаёмся
AUTOCONNECT_DELAY = 20          # сек. после старта Decky
AUTOCONNECT_WAIT = 180          # сколько ждать сеть и сессию пользователя
UPDATE_CACHE_SECONDS = 6 * 3600
IP_CACHE_SECONDS = 60
GITHUB_LATEST = "https://api.github.com/repos/AdguardTeam/AdGuardVPNCLI/releases/latest"
_IP_CACHE = {"ts": 0.0, "data": None}


def _settings_dir() -> str:
    return getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", None) or "/tmp/adguard-vpn-settings"


def _read_json(name: str) -> dict:
    try:
        with open(os.path.join(_settings_dir(), name), encoding="utf-8") as f:
            v = json.load(f)
            return v if isinstance(v, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as e:
        LOG.warning(f"{name}: {e}")
        return {}


def _write_json(name: str, data: dict) -> None:
    d = _settings_dir()
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, name)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(path + ".tmp", path)


def _load_settings() -> dict:
    raw = _read_json("settings.json")
    out = dict(DEFAULT_SETTINGS)
    for k, v in raw.items():                      # неизвестные/старые ключи просто игнорируем
        if k in out and isinstance(v, type(out[k])):
            out[k] = v
    return out


def _load_state() -> dict:
    return _read_json("state.json")


def _save_state(**kw) -> None:
    st = _load_state()
    st.update(kw, ts=time.strftime("%Y-%m-%d %H:%M:%S"))
    try:
        _write_json("state.json", st)
    except Exception as e:
        LOG.warning(f"state.json: {e}")


async def _toast(title: str, body: str) -> None:
    """Короткое уведомление в Steam (работает и при закрытой панели) — через событие фронтенду."""
    emit = getattr(decky, "emit", None)
    if emit:
        try:
            await emit("adguard_toast", title, body)
        except Exception as e:
            LOG.warning(f"emit: {e}")


def _http_json(url: str, timeout: int = 12):
    req = urllib.request.Request(url, headers={"User-Agent": "adguard-vpn-decky", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read(200_000).decode("utf-8", "replace"))


def _fetch_ip() -> dict:
    """Внешний IP и страна. Запрос идёт с устройства, т.е. через VPN, если он включён (режим TUN)."""
    errors = []
    for url, conv in (
        ("https://ipinfo.io/json", lambda d: (d.get("ip"), d.get("country"), d.get("city"))),
        ("https://ipwho.is/", lambda d: (d.get("ip"), d.get("country_code"), d.get("city"))
            if d.get("success", True) else (None, None, None)),
        ("https://api.country.is/", lambda d: (d.get("ip"), d.get("country"), "")),
    ):
        try:
            ip, cc, city = conv(_http_json(url, 8))
            if ip:
                return {"ok": True, "ip": ip, "country": (cc or "").upper()[:2], "city": city or "",
                        "source": url.split("/")[2]}
        except Exception as e:
            errors.append(f"{url.split('/')[2]}: {e}")
    return {"ok": False, "error": "; ".join(errors)[:300]}


def _version_tuple(v: str):
    m = re.search(r"(\d+)\.(\d+)(?:\.(\d+))?", v or "")
    return tuple(int(x or 0) for x in m.groups()) if m else None


def _plugin_version() -> str:
    base = getattr(decky, "DECKY_PLUGIN_DIR", None) or os.path.dirname(os.path.abspath(__file__))
    try:
        with open(os.path.join(base, "plugin.json"), encoding="utf-8") as f:
            return json.load(f).get("version", "")
    except Exception:
        return getattr(decky, "DECKY_PLUGIN_VERSION", "") or ""


# Формат `adguardvpn-cli license` (строки из CLI 1.8.3):
#   Logged in as user@example.com
#   You are using the PREMIUM version | You are using the FREE version
#   Up to 10 devices simultaneously
#   Your subscription is valid until 2027-05-01 | Your subscription will be renewed on 2027-05-01
#   You are out of free VPN traffic this month. VPN speed is limited
# Остаток бесплатного трафика — по любому «N MB|GB … left/remaining». Незнакомые строки не мешают.
def _parse_license(out: str) -> dict:
    t = _strip_ansi(out or "")
    info = {"email": "", "plan": "", "until": "", "renews": False, "devices": None,
            "traffic_left": "", "traffic_out": False}
    m = re.search(r"logged in as\s+(\S+@\S+)", t, re.IGNORECASE) or re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", t)
    if m:
        info["email"] = (m.group(1) if m.groups() else m.group(0)).rstrip(".,")
    m = re.search(r"using the\s+(\w+)\s+version", t, re.IGNORECASE) or \
        re.search(r"\b(premium|free|unlimited|trial)\b", t, re.IGNORECASE)
    if m:
        info["plan"] = m.group(1).upper()
    m = re.search(r"(valid until|renewed on|expires?(?: on)?|until)\s*:?\s*(\d{4}-\d{2}-\d{2}|\d{2}\.\d{2}\.\d{4})",
                  t, re.IGNORECASE)
    if m:
        d = m.group(2)
        info["until"] = ".".join(reversed(d.split("-"))) if "-" in d else d
        info["renews"] = "renew" in m.group(1).lower()
    m = re.search(r"up to\s+(\d+)\s+devices?", t, re.IGNORECASE) or re.search(r"(\d+)\s+devices?", t, re.IGNORECASE)
    if m:
        info["devices"] = int(m.group(1))
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(KB|MB|GB|TB)\b[^\n]*?\b(left|remaining)", t, re.IGNORECASE) or \
        re.search(r"(?:left|remaining)[^\n\d]*(\d+(?:[.,]\d+)?)\s*(KB|MB|GB|TB)\b", t, re.IGNORECASE)
    if m:
        info["traffic_left"] = f"{m.group(1).replace(',', '.')} {m.group(2).upper()}"
    info["traffic_out"] = bool(re.search(r"out of free (vpn )?traffic|traffic limit reached", t, re.IGNORECASE))
    return info


# ---------- журнал событий (показывается в панели) ----------

EVENTS_MAX = 50
_EVENTS = {"loaded": False, "items": []}

# Частые ошибки CLI → короткая подпись (полный текст остаётся в подробностях)
SUDO_LABEL = "Ошибка: нет прав sudo — перезапустите установщик"
ERROR_LABELS = [
    (re.compile(r"not logged in|please log in|log in first|login required|unauthori[sz]ed|session (has )?expired",
                re.I), "Ошибка: не выполнен вход"),
    (re.compile(r"password is required|a terminal is required|askpass|sudo:|not in the sudoers|"
                r"permission denied|not permitted", re.I), SUDO_LABEL),
    (re.compile(r"нет ответа|timed? ?out|timeout", re.I), "Ошибка: тайм-аут AdGuard"),
    (re.compile(r"network (is )?unreachable|no internet|could not resolve|name resolution|connection refused|"
                r"failed to connect to (the )?(server|endpoint)|no route to host|network error", re.I),
     "Ошибка: нет сети"),
    (re.compile(r"location .*(not found|unavailable|not available)|no such location|unknown location|"
                r"недопустимое имя локации|not available on (your|the free)", re.I), "Ошибка: локация недоступна"),
    (re.compile(r"traffic limit|out of free (vpn )?traffic", re.I), "Ошибка: закончился трафик"),
    (re.compile(r"too many devices", re.I), "Ошибка: много устройств"),
    (re.compile(r"subscription (has )?expired|license (has )?expired|no (active )?subscription", re.I),
     "Ошибка: нет подписки"),
]


def _explain_error(text: str) -> str:
    for rx, label in ERROR_LABELS:
        if rx.search(text or ""):
            return label
    return "Ошибка"


def _events_path() -> str:
    return os.path.join(_settings_dir(), "events.json")


def _events() -> list:
    if not _EVENTS["loaded"]:
        _EVENTS["loaded"] = True
        try:
            v = json.load(open(_events_path(), encoding="utf-8")).get("events", [])
            _EVENTS["items"] = [e for e in v if isinstance(e, dict)][-EVENTS_MAX:]
        except Exception:
            _EVENTS["items"] = []
    return _EVENTS["items"]


def _log_event(level: str, summary: str, details: str = "") -> dict:
    """level: info | ok | warn | error. Время — местное время устройства."""
    ev = {"id": time.time_ns(), "time": time.strftime("%H:%M:%S"), "date": time.strftime("%d.%m"),
          "level": level if level in ("info", "ok", "warn", "error") else "info",
          "summary": (summary or "")[:80], "details": _strip_ansi(details or "")[-4000:]}
    items = _events()
    items.append(ev)
    del items[:-EVENTS_MAX]
    try:
        _write_json("events.json", {"events": items})
    except Exception as e:
        LOG.warning(f"events.json: {e}")
    return ev


def _net_ok() -> bool:
    import socket
    for host in ("api.github.com", "ipinfo.io", "1.1.1.1"):
        try:
            socket.create_connection((host, 443), timeout=5).close()
            return True
        except Exception:
            continue
    return False


def _no_echo(fd: int) -> None:
    """Выключить эхо в pty (чтобы наши «s»/«x» не попадали в лог). termios может отсутствовать."""
    try:
        import termios
        attrs = termios.tcgetattr(fd)
        attrs[3] &= ~termios.ECHO
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
        return
    except Exception:
        pass
    try:
        subprocess.run(["stty", "-echo"], stdin=fd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=3)
    except Exception:
        pass


def _pump_login(fd: int, log_path: str) -> None:
    """Переписывает вывод `adguardvpn-cli login` из pty в login.log, пока процесс жив."""
    try:
        with open(log_path, "ab", buffering=0) as lf:
            while True:
                try:
                    chunk = os.read(fd, 4096)
                except OSError:                     # EIO — процесс закрыл терминал
                    break
                if not chunk:
                    break
                lf.write(chunk.replace(b"\r\n", b"\n"))
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
        if Plugin._login_fd == fd:
            Plugin._login_fd = None


def _login_write(data: bytes) -> None:
    fd = Plugin._login_fd
    if fd is None:
        raise OSError("login не запущен")
    os.write(fd, data)


def _marker_path() -> str:
    d = getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", None) or os.path.join(_user_home(), "homebrew/settings/adguard-vpn")
    return os.path.join(d, "install-complete")


def _read_marker() -> dict:
    """~/homebrew/settings/adguard-vpn/install-complete — пишет install-adguard-vpn-decky.sh в конце."""
    try:
        with open(_marker_path(), encoding="utf-8", errors="replace") as f:
            raw = f.read(2000)
    except Exception:
        return {}
    info = {"raw": raw.strip()}
    for line in raw.splitlines():
        k, _, v = line.partition("=")
        if k.strip() in ("version", "date", "system", "user"):
            info[k.strip()] = v.strip()
    return info


def _check_sudo(cli):
    """Работает ли sudo без пароля у пользователя (так его вызывает adguard-vpn.sh)."""
    pw = _pw()
    tries = [["sudo", "-n", "true"]]
    if cli:
        tries.append(["sudo", "-n", "-l", cli])        # правило только для adguardvpn-cli
    last = ""
    for args in tries:
        # Как скрипт: через systemd --user (у службы Decky может стоять NoNewPrivileges — тогда
        # sudo из неё не сработает, хотя у пользователя всё в порядке), иначе напрямую.
        if pw and _user_session_ok():
            cmd = ["systemd-run", f"--machine={pw.pw_name}@.host", "--user", "--quiet", "--collect",
                   "--wait", "--pipe", "--"] + args
            env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin"}
        else:
            cmd, env = _as_user(args), _user_env()
        try:
            r = subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, errors="replace", timeout=20, env=env, cwd="/")
            if r.returncode == 0:
                return True, ""
            last = _strip_ansi(r.stdout).strip()[:160]
        except Exception as e:
            last = str(e)
    return False, last


def _pidfile() -> str:
    pw = _pw()
    d = f"/run/user/{pw.pw_uid}" if pw and os.path.isdir(f"/run/user/{pw.pw_uid}") else tempfile.gettempdir()
    return os.path.join(d, "adguard-vpn-script.pid")


def _children_map() -> dict:
    kids = {}
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            with open(f"/proc/{pid}/stat") as f:
                ppid = int(f.read().rsplit(")", 1)[1].split()[1])
            kids.setdefault(ppid, []).append(int(pid))
        except Exception:
            continue
    return kids


def _tree(root: int) -> list:
    kids, out, todo = _children_map(), [], [root]
    while todo:
        p = todo.pop()
        out.append(p)
        todo.extend(kids.get(p, []))
    return out


def _kill_script(cur: dict) -> None:
    """Убить встроенный скрипт и его потомков (connect/sudo). Демон туннеля уже отцеплен — его не трогаем."""
    roots = []
    pf = cur.get("pidfile")
    if pf:
        try:
            roots.append(int(open(pf).read().strip()))
        except Exception:
            pass
    proc = cur.get("proc")
    if proc is not None and proc.poll() is None:
        roots.append(proc.pid)
    pids = []
    for r in roots:
        for p in _tree(r):
            if p not in pids and p > 1:
                pids.append(p)
    for sig in (signal.SIGTERM, signal.SIGKILL):
        for p in reversed(pids):
            try:
                os.kill(p, sig)
            except Exception:
                pass
        time.sleep(1.0)
    if proc is not None:
        try:
            proc.wait(timeout=2)
        except Exception:
            pass
    if pids:
        LOG.warning(f"остановлены процессы скрипта: {pids}")


def _tail_file(path: str, n: int) -> str:
    try:
        lines = _strip_ansi(open(path, encoding="utf-8", errors="replace").read()).splitlines()[1:]
        return "\n".join(lines[-n:]).strip()
    except Exception:
        return ""


def _who_am_i() -> str:
    pw = _pw()
    home = _user_home()
    cfg = os.path.join(home, ".local/share/adguardvpn-cli")
    return (f"пользователь: {pw.pw_name if pw else '?'} (uid {pw.pw_uid if pw else '?'}, "
            f"определён по: {_USER_CACHE.get('how') or '—'})\nHOME: {home}\n"
            f"настройки CLI: {cfg} ({'есть' if os.path.isdir(cfg) else 'НЕТ'})\n"
            f"плагин работает как uid {os.geteuid()}")


def _logged(fn):
    """Исключение в методе бэкенда → запись в Журнал и понятный ответ (а не вечное ожидание)."""
    import functools

    @functools.wraps(fn)
    async def wrap(self, *a, **kw):
        try:
            return await fn(self, *a, **kw)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            LOG.exception(fn.__name__)
            _log_event("error", f"Ошибка плагина: {fn.__name__}", f"{type(e).__name__}: {e}")
            return {"ok": False, "error": "exception", "message": f"Ошибка плагина: {e}"}
    return wrap


class Plugin:
    _running = {}
    _cur = {}
    _auth = None
    _action_lock = None
    _watchdog_task = None
    _auto_task = None
    _update_proc = None
    _update_logged = True
    _status_err = ""
    _login_logged = True
    _update_cache = {"ts": 0.0, "data": None}
    _wd = {"fails": 0, "next": 0.0}

    async def get_status(self) -> dict:
        """ТОЛЬКО ЧТЕНИЕ: adguardvpn-cli status от имени пользователя (без sudo)."""
        def bad(raw, code, error):
            return {"state": "unknown", "connected": False, "location": None, "location_text": "",
                    "raw": raw, "code": code, "error": error}
        if not _cli_path():
            return bad(f"Не найден {CLI_PATH}", -2, "cli_not_found")
        r = await _cli_once(["status"], STATUS_TIMEOUT)
        if r.get("error") == "user_unknown":
            return bad(r["output"], r["code"], "user_unknown")
        if r["timeout"] and Plugin._status_err != "timeout":
            _log_event("warn", "Ошибка: тайм-аут AdGuard (status)", f"нет ответа за {STATUS_TIMEOUT} сек.\n"
                       f"{_app_log_tail(6)}")
        Plugin._status_err = "timeout" if r["timeout"] else ""
        if r["timeout"]:
            tail = _app_log_tail(3)
            return bad(f"status не ответил за {STATUS_TIMEOUT} сек. Обычно это медленная или фильтруемая сеть: "
                       f"при каждом запуске adguardvpn-cli сначала связывается с серверами AdGuard."
                       + (f"\n\napp.log:\n{tail}" if tail else ""), -1, "timeout")
        if r.get("error") == "killed":            # прервано входом — интерфейс оставит прошлый статус
            return bad(r["output"], -5, "timeout")
        if r["code"] == -3:
            return bad(r["output"], -3, "spawn_failed")
        if r.get("error") == "not_configured":
            return bad(r["output"], r["code"], "not_configured")
        st = _parse_status(r["output"], r["code"])
        if r.get("seconds", 0) > SLOW_CLI_SECONDS:
            st["slow"] = r["seconds"]
        return st

    @_logged
    async def run_action(self, action: str, label: str = "") -> dict:
        """Кнопка в панели: действие пользователя (запоминается для автоподключения и сторожа)."""
        if action == "off" and Plugin._cur.get("proc") is not None:
            # «Отключить» во время подключения = отмена зависшего/долгого connect
            await self._cancel_action("нажато «Отключить»")
        return await self._do_action(action, label, source="user")

    async def cancel_action(self) -> dict:
        n = await self._cancel_action("отмена из панели")
        return {"ok": True, "cancelled": bool(n)}

    async def _cancel_action(self, why: str) -> int:
        """Отменить идущее действие: убить скрипт и всё, что он запустил (не демон туннеля)."""
        cur = Plugin._cur
        proc = cur.get("proc")
        if proc is None:
            return 0
        cur["cancelled"] = why
        await asyncio.to_thread(_kill_script, cur)
        _log_event("warn", f"Отменено: {cur.get('name') or 'действие'}", f"причина: {why}")
        return 1

    async def _do_action(self, action: str, label: str = "", source: str = "user") -> dict:
        if Plugin._action_lock is None:
            Plugin._action_lock = asyncio.Lock()
        who = {"user": "", "watchdog": " (сторож)", "autoconnect": " (автозапуск)"}.get(source, "")
        name = label or ("самая быстрая" if action == "fastest" else action.replace("loc:", ""))
        if action != "off":
            _log_event("info", f"▶ Подключение: {name}{who}", f"действие: {action}\n{_who_am_i()}")
        cancelled = None
        if Plugin._action_lock.locked():
            _log_event("info", f"Ждёт очереди: {name}{who}", "идёт другое действие")
        try:
            async with Plugin._action_lock:
                Plugin._cur = {"name": name, "action": action}
                try:
                    res = await self._run_action_impl(action)
                finally:
                    cancelled = Plugin._cur.get("cancelled")
                    Plugin._cur = {}
        except asyncio.CancelledError:
            raise
        except Exception as e:
            LOG.exception("action failed")
            res = {"ok": False, "message": f"Ошибка плагина: {e}"}
        if cancelled and not res.get("ok"):
            res.update(message=f"Отменено ({cancelled})", cancelled=True)
        _IP_CACHE["ts"] = 0.0                       # IP после действия — заново
        if source != "watchdog":
            Plugin._wd.update(fails=0, next=0.0)    # новое действие пользователя — счётчик попыток с нуля
        st = res.get("status") or {}
        if res.get("ok") and action == "off":
            _save_state(desired="disconnected", gave_up=False)
        elif res.get("ok") and action != "off":
            if source == "user" or st.get("connected"):
                # «самая быстрая» — запоминаем, куда реально подключились (для переподключения туда же)
                last = action
                loc = (st.get("location_text") or "").strip()
                if action == "fastest" and loc and _location_target("loc:" + loc.title()):
                    last = "loc:" + loc.title()
                upd = {"desired": "connected", "gave_up": False}
                if source == "user":
                    upd.update(last_action=last, last_label=label or loc or action)
                _save_state(**upd)
        LOG.info(f"action[{source}] {action!r} -> ok={res.get('ok')} {res.get('message')!r}")
        if AUTH_RE.search(f"{res.get('output', '')}") and not res.get("ok"):
            Plugin._auth = False
            res["message"] = "Не выполнен вход в AdGuard — нажмите «🔑 Войти»"
        name = label or (st.get("location_text") or "").title() or \
            ("самая быстрая" if action == "fastest" else action.replace("loc:", ""))
        details = f"действие: {action}\nкод: {res.get('code', '—')}\n{res.get('output', '')}".strip()
        if st.get("raw"):
            details += f"\n\nstatus:\n{st['raw']}"
        if res.get("cancelled"):
            res["error_label"] = "Отменено"
        elif not res.get("ok"):
            label_err = res.get("error_label") or _explain_error(f"{res.get('message', '')}\n{res.get('output', '')}")
            if label_err == SUDO_LABEL:
                res["message"] = "Нет прав sudo — перезапустите установщик"
            res["error_label"] = label_err
            _log_event("error", f"{label_err}{who}", f"{res.get('message', '')}\n{details}")
        elif action == "off":
            _log_event("info", "VPN отключён" + who, details)
        elif res.get("warning"):
            _log_event("warn", f"{name}: CLI «успех», но статус «отключено»{who}", details)
        else:
            verb = "Переподключено" if source == "watchdog" else "Подключено"
            _log_event("ok", f"{verb}: {name}{who}", details)
        return res

    async def _run_action_impl(self, action: str) -> dict:
        """
        Действие кнопки: "Slovakia" | "Germany" | "Sweden" | "Kazakhstan" | "off" | "loc:<локация>".
        Всегда встроенный adguard-vpn.sh. Процесс НЕ убиваем: ждём завершения только чтобы показать итог.
        """
        if os.geteuid() == 0 and not _pw():
            return {"ok": False, "message": "Не удалось определить пользователя Steam — от root скрипт не запускаю. "
                                            "Перезапустите Decky (или устройство)."}
        action = (action or "").strip()
        choice = BUNDLED_MAPPING.get(action, action)
        target = _location_target(choice)
        if choice.startswith("loc:") and not target:
            return {"ok": False, "message": f"Недопустимое имя локации: {choice[4:][:40]!r}"}
        if target:
            args = ["connect", target]
        elif choice in LEGACY_CHOICES:
            args = [choice]
        else:
            return {"ok": False, "message": f"Неизвестное действие: {action[:40]!r}"}
        try:
            real = os.path.realpath(_bundled_script())
            if not os.path.isfile(real):
                return {"ok": False, "message": "Встроенный скрипт adguard-vpn.sh не найден. Переустановите плагин."}
            prev = Plugin._running.get(real)
            if prev and prev.poll() is None:
                return {"ok": False, "message": "Предыдущее действие ещё выполняется, подождите"}
            pidfile = _pidfile()
            try:
                os.remove(pidfile)
            except OSError:
                pass
            proc, log_path = await self._launch(real, args, "script.log", pidfile=pidfile)
            Plugin._running[real] = proc
            Plugin._cur.update(proc=proc, pidfile=pidfile, started=time.monotonic())
            t0 = time.monotonic()
            next_note = PROGRESS_EVERY
            killed = ""
            while proc.poll() is None:
                await asyncio.sleep(0.5)
                el = time.monotonic() - t0
                if Plugin._cur.get("cancelled"):
                    killed = "cancel"
                    break
                if el >= next_note:
                    next_note += PROGRESS_EVERY
                    tail = _tail_file(log_path, 3)
                    _log_event("warn" if el >= SCRIPT_TIMEOUT else "info",
                               f"{args[0]} идёт {int(el)} с…", tail or "вывода пока нет")
                if el >= SCRIPT_HARD_TIMEOUT:
                    killed = "timeout"
                    await asyncio.to_thread(_kill_script, Plugin._cur)
                    _log_event("error", f"Тайм-аут {SCRIPT_HARD_TIMEOUT} с — остановлено", _tail_file(log_path, 8))
                    break
            out = _strip_ansi(open(log_path, encoding="utf-8", errors="replace").read())
            body = "\n".join(l for l in out.splitlines() if not l.startswith("=== ") or l == "=== status ===").strip()
            # Встроенный скрипт после действия печатает `adguardvpn-cli status`
            script_status = None
            if "=== status ===" in body:
                head, _, tail = body.rpartition("=== status ===")
                m = re.search(r"status_code=(-?\d+)", tail)
                st_text = tail[:m.start()] if m else tail
                script_status = _parse_status(st_text, int(m.group(1)) if m else 0)
                body = head.strip()
            LOG.info(f"run_action finished code={proc.poll()}: {body[-600:]!r}")
            if killed:
                await asyncio.to_thread(_kill_script, Plugin._cur)
                if killed == "timeout":
                    return {"ok": False, "message": f"AdGuard не ответил за {SCRIPT_HARD_TIMEOUT} с — остановлено",
                            "output": body, "code": proc.poll(), "error_label": "Ошибка: тайм-аут AdGuard"}
                return {"ok": False, "message": "Отменено", "output": body, "code": proc.poll(), "cancelled": True}
            res = self._script_result(proc, body, choice)
            res["code"] = proc.poll()
            if script_status:
                res["status"] = script_status
                if choice == "off" and script_status["state"] == "disconnected":
                    res.update(ok=True, message="VPN отключён")
                if res["ok"] and choice and choice != "off" and script_status["state"] == "disconnected":
                    res["warning"] = "CLI сообщил об успехе, но status показывает «отключено»"
            return res
        except Exception as e:
            LOG.exception("run_action failed")
            return {"ok": False, "message": f"Ошибка запуска скрипта: {e}"}

    @staticmethod
    async def _launch(real: str, args: list, log_name: str, pidfile: str = ""):
        """Запуск встроенного скрипта от имени пользователя, отсоединённо; вывод — в log_name."""
        env = _user_env()
        if pidfile:
            env["ADGUARD_VPN_PIDFILE"] = pidfile
        cmd = ["/bin/bash", real] + args       # локация — отдельный argv-элемент, без shell
        if await asyncio.to_thread(_user_session_ok):
            # Запуск в сессии пользователя (systemd --user), как запускает Steam:
            # процесс и поднятый CLI туннель живут вне службы plugin_loader.
            # KillMode=process: когда скрипт закончится, туннель не трогается.
            unit = f"adguard-vpn-script-{time.time_ns()}"
            cmd = ["systemd-run", f"--machine={_target_user()}@.host", "--user", "--quiet",
                   "--collect", "--wait", "--pipe", f"--unit={unit}",
                   "-p", "KillMode=process", "--working-directory=/"] + \
                  [f"--setenv={k}={v}" for k, v in env.items()
                   if k in ("PATH", "LANG", "HOME", "SUDO_ASKPASS", "ADGUARD_VPN_PIDFILE", "XDG_CONFIG_HOME",
                            "XDG_DATA_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME")] + ["--"] + cmd
        else:
            cmd = _as_user(cmd)
        log_path = os.path.join(_log_dir(), log_name)
        LOG.info(f"launch: {cmd}")
        with open(log_path, "w", encoding="utf-8") as lf:
            lf.write(f"=== {time.strftime('%Y-%m-%d %H:%M:%S')} {' '.join(cmd)}\n")
            lf.flush()
            proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=lf, stderr=subprocess.STDOUT,
                                    env=env, cwd=os.path.dirname(real) or "/",
                                    start_new_session=True, close_fds=True)
        # Отдельный поток только «подбирает» завершившийся процесс (без зомби)
        threading.Thread(target=proc.wait, daemon=True).start()
        return proc, log_path

    @staticmethod
    def _script_result(proc, body: str, choice: str) -> dict:
        if proc.poll() is None:
            return {"ok": True, "message": "Скрипт запущен и ещё работает",
                    "output": body, "running": True}
        ok_conn = re.search(r"successfully connected to\s+([^\r\n.]+)", body, re.IGNORECASE)
        if ok_conn:
            msg = f"Подключено: {ok_conn.group(1).strip()}"
            if "dns could not be configured" in body.lower():
                msg += " (предупреждение: системный DNS не настроен)"
            return {"ok": True, "message": msg, "output": body}
        if re.search(r"disconnected|stopped|process is not running", body, re.IGNORECASE) and choice:
            return {"ok": True, "message": "VPN отключён", "output": body}
        if proc.returncode == 0:
            return {"ok": True, "message": "Скрипт выполнен", "output": body}
        last = body.splitlines()[-1] if body else f"код {proc.returncode}"
        return {"ok": False, "message": f"Скрипт завершился с ошибкой: {last[:160]}", "output": body}

    # ---------- пинг ----------

    _ping_cache = {"ts": 0.0, "data": None}
    _ping_lock = None

    async def get_pings(self, force: bool = False) -> dict:
        """Пинг до Словакии/Германии/Швеции из `adguardvpn-cli list-locations` (кеш 45 сек.)."""
        if Plugin._ping_lock is None:
            Plugin._ping_lock = asyncio.Lock()
        async with Plugin._ping_lock:
            c = Plugin._ping_cache
            if not force and c["data"] is not None and time.monotonic() - c["ts"] < PING_CACHE_SECONDS:
                return dict(c["data"], age=int(time.monotonic() - c["ts"]))
            r = await _cli_once(["list-locations"], PING_TIMEOUT)
            out = r["output"]
            if r["code"] == -2:
                data = {"ok": False, "pings": {}, "error": "cli_not_found"}
            elif r.get("error") in ("user_unknown", "not_configured"):
                data = {"ok": False, "pings": {}, "error": r["error"]}
            elif r["timeout"]:
                data = {"ok": False, "pings": {}, "error": "timeout"}
            elif AUTH_RE.search(out):
                data = {"ok": False, "pings": {}, "error": "not_logged_in"}
            else:
                rows = _parse_locations(out)
                pings = _pings_from_rows(rows)
                data = {"ok": bool(rows), "pings": pings, "error": None if rows else "no_data",
                        "count": len(rows), "rows": rows}
                if not rows:
                    LOG.warning(f"list-locations: не удалось разобрать вывод: {out[:300]!r}")
            Plugin._ping_cache = {"ts": time.monotonic(), "data": data}
            return dict(data, age=0)

    # ---------- все локации (для «Другие») ----------

    async def get_locations(self, force: bool = False) -> dict:
        """
        Все локации аккаунта из `adguardvpn-cli list-locations` (тот же кеш 45 сек., что и пинг).
        Если CLI недоступен — встроенный список (без пинга).
        """
        await self.get_pings(force)
        data = Plugin._ping_cache["data"] or {}
        age = int(time.monotonic() - Plugin._ping_cache["ts"])
        rows = data.get("rows") or []
        if rows:
            return {"ok": True, "source": "cli", "locations": rows, "error": None, "age": age}
        return {"ok": False, "source": "fallback", "locations": _fallback_locations(),
                "error": data.get("error") or "no_data", "age": age}

    # ---------- избранное (JSON в папке настроек плагина) ----------

    async def get_favorites(self) -> list:
        return _load_favorites()

    async def set_favorite(self, key: str, on: bool) -> list:
        favs = [k for k in _load_favorites() if k != key]
        if on and isinstance(key, str) and 0 < len(key) <= 100:
            favs.append(key)
        _save_favorites(favs)
        return favs

    # ---------- аккаунт ----------

    _login_proc = None
    _login_fd = None
    _login_started = 0.0
    _login_answered = False

    @_logged
    async def account_info(self) -> dict:
        """`adguardvpn-cli license` (только чтение): вошёл ли пользователь и какая подписка."""
        r = await _cli_once(["license"], STATUS_TIMEOUT)
        out = r["output"]
        if r["code"] == -2:
            return {"cli": False, "logged_in": False, "raw": out}
        if r["timeout"] or r.get("error"):
            # Не знаем точно → logged_in = None; интерфейс всё равно покажет «Войти».
            return {"cli": True, "logged_in": None, "plan": "", "email": "", "raw": out, "code": r["code"],
                    "no_subscription": False, "timeout": r["timeout"], "error": r.get("error") or "timeout"}
        logged_in = None
        if AUTH_RE.search(out):
            logged_in = False
        elif r["code"] == 0 and out:
            logged_in = True
        if logged_in is not None:
            Plugin._auth = logged_in
        lic = _parse_license(out) if logged_in else {}
        return dict(lic, cli=True, logged_in=logged_in, plan=lic.get("plan", ""), email=lic.get("email", ""),
                    raw=out, code=r["code"], no_subscription=bool(LICENSE_RE.search(out)))

    @_logged
    async def login_start(self) -> dict:
        """Запускает `adguardvpn-cli login` от имени пользователя и ждёт, пока он покажет ссылку."""
        cli = _cli_path()
        if not cli:
            _log_event("error", "Ошибка: adguardvpn-cli не установлен", CLI_PATH)
            return {"ok": False, "message": f"adguardvpn-cli не найден ({CLI_PATH}). Сначала установите его."}
        if os.geteuid() == 0 and not _pw():
            _log_event("error", "Ошибка: не найден пользователь", "")
            return {"ok": False, "message": "Не удалось определить пользователя Steam (DECKY_USER). "
                                            "Перезапустите Decky или устройство."}
        p = Plugin._login_proc
        if p and p.poll() is None:
            return await self.login_poll()
        _log_event("info", "Вход: запуск (login started)", _who_am_i())
        # Вход важнее всего: прерываем идущее подключение/автоподключение и зависшие status/license
        if Plugin._cur.get("proc") is not None:
            await self._cancel_action("нажато «Войти»")
        n = await asyncio.to_thread(_kill_all_cli, "вход")
        if n:
            _log_event("info", f"Вход: прервано команд AdGuard: {n}", "status/license/list-locations")
        log_path = os.path.join(_log_dir(), "login.log")
        with open(log_path, "w", encoding="utf-8") as lf:
            lf.write(f"=== {time.strftime('%Y-%m-%d %H:%M:%S')} adguardvpn-cli login\n")
        # CLI 1.8.3 буферизует вывод, если stdout — файл/pipe: ссылка появлялась только после
        # завершения login (проверено) → в 1.0.7 плагин её не видел. Поэтому даём ему
        # псевдотерминал (как в Konsole): ссылка приходит сразу, а «s»/«x» пишем в тот же pty.
        # 1.1.1: os.openpty() вместо модуля pty — в Decky 3.3+ (Python 3.14) нет pty/termios,
        # `import pty` ронял весь бэкенд при загрузке.
        master, slave = os.openpty()
        _no_echo(slave)
        env = _user_env()
        env["TERM"] = "dumb"
        try:
            Plugin._login_proc = subprocess.Popen(
                _as_user([cli, "login"]), stdin=slave, stdout=slave, stderr=slave,
                env=env, cwd="/", start_new_session=True, close_fds=True)
        except Exception as e:
            os.close(master)
            os.close(slave)
            return {"ok": False, "message": f"Не удалось запустить вход: {e}"}
        os.close(slave)
        Plugin._login_fd = master
        threading.Thread(target=_pump_login, args=(master, log_path), daemon=True).start()
        Plugin._login_started = time.monotonic()
        Plugin._login_answered = False
        threading.Thread(target=Plugin._login_proc.wait, daemon=True).start()
        LOG.info("login started")
        Plugin._login_logged = False
        for _ in range(30):                      # до 15 сек. ждём ссылку, дальше интерфейс опрашивает сам
            await asyncio.sleep(0.5)
            st = await self.login_poll()
            if st.get("url") or st.get("done"):
                return st
        return await self.login_poll()

    async def login_poll(self) -> dict:
        log_path = os.path.join(_log_dir(), "login.log")
        try:
            text = _strip_ansi(open(log_path, encoding="utf-8", errors="replace").read())
        except Exception:
            text = ""
        body = "\n".join(text.splitlines()[1:]).strip()
        p = Plugin._login_proc
        running = bool(p and p.poll() is None)
        # Вопрос первого запуска внутри login (если CLI его задаст) — отвечаем «n» один раз.
        if running and not Plugin._login_answered and body and CONSENT_RE.search(body.splitlines()[-1]) \
                and not LOGIN_URL_RE.search(body):
            try:
                _login_write(b"n\n")
                Plugin._login_answered = True
                LOG.info(f"login: ответили «n» на вопрос: {body.splitlines()[-1][:200]!r}")
            except Exception:
                pass
        url = _extract_login_url(body)
        code_m = LOGIN_CODE_RE.search(body)
        code = (code_m.group(1) or code_m.group(2)) if code_m else ""
        ttl_m = LOGIN_TTL_RE.search(body)
        ttl = int(ttl_m.group(1)) if ttl_m else 0
        left = max(0, int(ttl - (time.monotonic() - Plugin._login_started))) if ttl else 0
        success = bool(LOGIN_OK_RE.search(body))
        fail = None
        if not running and not success:
            fm = LOGIN_FAIL_RE.search(body)
            fail = fm.group(1).strip() if fm else (f"login завершился (код {p.returncode})" if p else "")
        if (success or (fail and not running)) and not Plugin._login_logged:
            Plugin._login_logged = True
            if success:
                Plugin._auth = True
                Plugin._wd.update(fails=0, next=0.0)
                _log_event("ok", "Вход выполнен", body[-1500:])
            else:
                _log_event("error", "Ошибка: вход не выполнен", f"{fail}\n{body[-1500:]}")
        return {"ok": True, "running": running, "url": url, "code": code, "seconds_left": left,
                "done": success, "error": fail, "output": body[-1500:]}

    async def login_cancel(self) -> dict:
        p = Plugin._login_proc
        if p and p.poll() is None:
            try:
                _login_write(b"x\n")              # пункт меню CLI «x - Cancel»
            except Exception:
                pass
            await asyncio.sleep(1.5)
            if p.poll() is None:
                try:
                    os.killpg(p.pid, signal.SIGTERM)   # только процесс входа, VPN не трогаем
                except Exception:
                    p.terminate()
        LOG.info("login cancelled")
        if not Plugin._login_logged:
            Plugin._login_logged = True
            _log_event("info", "Вход отменён", "")
        return {"ok": True, "message": "Вход отменён"}

    async def login_speedup(self) -> dict:
        """Пункт меню CLI «s - Speed up check»: проверить подтверждение сразу."""
        p = Plugin._login_proc
        if p and p.poll() is None:
            try:
                _login_write(b"s\n")
            except Exception:
                pass
        await asyncio.sleep(2)
        return await self.login_poll()

    @_logged
    async def logout(self) -> dict:
        r = await asyncio.to_thread(_run_cli_sync, ["logout"], STATUS_TIMEOUT)
        LOG.info(f"logout -> {r['code']}: {r['output'][:300]!r}")
        ok = r["code"] == 0 or "logged out" in r["output"].lower()
        _log_event("info" if ok else "error", "Выход из аккаунта" if ok else "Ошибка: выход не выполнен",
                   f"код: {r['code']}\n{r['output']}")
        return {"ok": ok, "message": "Вы вышли из аккаунта AdGuard" if ok else f"Не удалось выйти: {r['output'][:160]}",
                "output": r["output"]}

    # ---------- проверка установки ----------

    @_logged
    async def check_setup(self) -> dict:
        """
        Всё ли установлено: CLI, CLI отвечает, правило sudo, встроенный скрипт, вход, отметка установщика.
        Каждый пункт: id, ok, label (что не так — по-русски), step (шаг инструкции).
        """
        items = []

        def add(id_, ok, label, step, hint="", required=True):
            items.append({"id": id_, "ok": bool(ok), "label": label, "step": step, "hint": hint,
                          "required": required})

        user_ok = not (os.geteuid() == 0 and not _pw())
        add("user", user_ok, "Не удалось определить пользователя Steam", "часть 12",
            "Перезапустите Decky или устройство")

        cli = _cli_path()
        add("cli", bool(cli), "Не установлена программа adguardvpn-cli", "шаг 1 (часть 3)")

        logged_in = None
        responds = False
        if cli and user_ok:
            r = await _cli_once(["license"], STATUS_TIMEOUT)
            responds = not r["timeout"] and r["code"] not in (-1, -3, -4) and r.get("error") != "not_configured"
            if responds:
                if AUTH_RE.search(r["output"]):
                    logged_in = False
                elif r["code"] == 0 and r["output"]:
                    logged_in = True
            hint = ("нет ответа за {} сек. — обычно медленная сеть".format(STATUS_TIMEOUT) if r["timeout"]
                    else "вопрос первого запуска: adguardvpn-cli config set-crash-reporting off"
                    if r.get("error") == "not_configured" else r["output"][:120])
            add("cli_responds", responds, "adguardvpn-cli не отвечает", "часть 12", "" if responds else hint)

        sudo_ok, sudo_how = (await asyncio.to_thread(_check_sudo, cli)) if user_ok else (False, "")
        add("sudoers", sudo_ok, "Нет правила sudo без пароля — VPN не сможет включиться из плагина",
            "шаг 3 (часть 4)", sudo_how)

        script = _bundled_script()
        exists = os.path.isfile(script) and os.access(script, os.R_OK)
        add("script", exists, "Нет встроенного скрипта adguard-vpn.sh в папке плагина", "шаг 8 (часть 9)",
            "" if exists else script)

        # Отметка установщика — справочно: при ручной установке по инструкции её нет, и это нормально.
        marker = _read_marker()
        add("installer", bool(marker), "Скрипт установки не дошёл до конца (или не запускался)", "быстрая установка",
            marker.get("raw", "") if marker else "", required=False)

        if cli and responds:
            add("login", logged_in is True, "Не выполнен вход в аккаунт AdGuard", "шаг 4 (часть 5)",
                required=True)

        failed = [i for i in items if i["required"] and not i["ok"]]
        only_login = bool(failed) and all(i["id"] == "login" for i in failed)
        res = {"ok": not failed, "only_login_missing": only_login, "logged_in": logged_in,
               "items": items, "marker": marker or None,
               "missing": [i for i in failed if i["id"] != "login"]}
        if res["missing"] and not marker:
            # Что-то не так и установщик не оставил отметку — значит, он не дошёл до конца (или не запускался)
            res["missing"].append(next(i for i in items if i["id"] == "installer"))
        if failed:
            LOG.info("check_setup: не хватает: " + ", ".join(i["id"] for i in failed))
        return res


    # ---------- настройки (1.1.0) ----------

    async def get_settings(self) -> dict:
        st = _load_state()
        return dict(_load_settings(), last_action=st.get("last_action", ""), last_label=st.get("last_label", ""),
                    desired=st.get("desired", ""), gave_up=bool(st.get("gave_up")),
                    plugin_version=_plugin_version())

    async def set_settings(self, changes: dict) -> dict:
        cur = _load_settings()
        for k, v in (changes or {}).items():
            if k in DEFAULT_SETTINGS and isinstance(v, type(DEFAULT_SETTINGS[k])):
                if k == "autoconnect_action" and v != "last" and v not in BUNDLED_MAPPING \
                        and v != "fastest" and not _location_target(v):
                    continue
                cur[k] = v[:80] if isinstance(v, str) else v
        _write_json("settings.json", cur)
        if cur["reconnect"]:
            _save_state(gave_up=False)
            Plugin._wd.update(fails=0, next=0.0)
        LOG.info(f"settings: {cur}")
        return await self.get_settings()

    # ---------- сторож: переподключение при обрыве ----------

    async def _watchdog_tick(self) -> str:
        """Одна проверка. Возвращает, что сделано (для журнала и тестов)."""
        cfg, st = _load_settings(), _load_state()
        if not cfg["reconnect"]:
            Plugin._wd.update(fails=0, next=0.0)
            return "off"
        if st.get("desired") != "connected" or not st.get("last_action") or st.get("gave_up"):
            return "idle"
        if Plugin._action_lock is not None and Plugin._action_lock.locked():
            return "busy"
        if Plugin._login_proc is not None and Plugin._login_proc.poll() is None:
            return "login"
        if time.monotonic() < Plugin._wd["next"]:
            return "wait"
        r = await _cli_once(["status"], STATUS_TIMEOUT)
        if r["timeout"] or r.get("error") or r["code"] < 0:
            return "unknown"                       # медленная сеть / нет CLI — ничего не делаем
        status = _parse_status(r["output"], r["code"])
        if status.get("error") or status["state"] != "disconnected":
            if status.get("connected"):
                Plugin._wd.update(fails=0, next=0.0)
            return status["state"] if not status.get("error") else status["error"]
        # VPN должен быть включён (пользователь не нажимал «Отключить»), а он выключен
        n = Plugin._wd["fails"]
        if n >= len(RECONNECT_DELAYS):
            _save_state(gave_up=True)
            await _toast("❌ VPN не восстановлен", "См. Журнал")
            LOG.warning("watchdog: 3 попытки не удались — сдаюсь")
            _log_event("error", "Сторож: VPN не восстановлен (3 попытки)", f"локация: {st.get('last_action')}")
            return "gave_up"
        if Plugin._wd["next"] == 0.0:
            Plugin._wd["next"] = time.monotonic() + RECONNECT_DELAYS[n]
            LOG.info(f"watchdog: VPN выключен неожиданно; попытка {n + 1} через {RECONNECT_DELAYS[n]} сек.")
            if n == 0:
                _log_event("warn", "Обрыв VPN — переподключаю", f"status:\n{r['output']}")
            return "scheduled"
        if Plugin._auth is False:
            _save_state(gave_up=True)
            _log_event("warn", "Сторож: не выполнен вход — переподключение выключено", "войдите в AdGuard")
            return "not_logged_in"
        Plugin._wd["fails"] = n + 1
        res = await self._do_action(st["last_action"], st.get("last_label", ""), source="watchdog")
        ok = bool(res.get("ok")) and (res.get("status") or {}).get("state") != "disconnected"
        if not ok and (Plugin._auth is False or res.get("error_label") == SUDO_LABEL or res.get("cancelled")):
            _save_state(gave_up=True)
            Plugin._wd.update(fails=0, next=0.0)
            _log_event("error", "Сторож остановлен: " + ("отмена" if res.get("cancelled") else
                       "нет входа" if Plugin._auth is False else "нет прав sudo"), res.get("message", ""))
            await _toast("❌ Переподключение", "См. Журнал")
            return "stopped"
        if ok:
            Plugin._wd.update(fails=0, next=0.0)
            await _toast("🔄 VPN переподключён", (st.get("last_label") or st["last_action"])[:40])
            return "reconnected"
        nxt = Plugin._wd["fails"]
        Plugin._wd["next"] = time.monotonic() + (RECONNECT_DELAYS[nxt] if nxt < len(RECONNECT_DELAYS) else 0)
        return "retry_failed"

    async def _watchdog(self):
        await asyncio.sleep(WATCHDOG_INTERVAL)
        while True:
            try:
                what = await self._watchdog_tick()
                if what not in ("off", "idle", "connected", "wait"):
                    LOG.info(f"watchdog: {what}")
            except asyncio.CancelledError:
                raise
            except Exception:
                LOG.exception("watchdog")
            await asyncio.sleep(WATCHDOG_INTERVAL if Plugin._wd["next"] == 0.0 else 5)

    # ---------- автоподключение при запуске ----------

    async def _autoconnect_safe(self):
        try:
            return await self._autoconnect()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            LOG.exception("autoconnect")
            _log_event("error", "Автоподключение: ошибка плагина", f"{type(e).__name__}: {e}")

    async def _autoconnect(self, delay: int = AUTOCONNECT_DELAY, wait: int = AUTOCONNECT_WAIT) -> str:
        cfg = _load_settings()
        if not cfg["autoconnect"]:
            return "off"
        _log_event("info", f"Автоподключение через {delay} с", f"локация: {cfg['autoconnect_label'] or cfg['autoconnect_action']}")
        await asyncio.sleep(delay)
        deadline = time.monotonic() + wait
        while time.monotonic() < deadline:
            if (os.geteuid() != 0 or await asyncio.to_thread(_user_session_ok)) and await asyncio.to_thread(_net_ok):
                break
            await asyncio.sleep(10)
        else:
            LOG.warning("autoconnect: нет сети или сессии пользователя — пропускаю")
            _log_event("error", "Автоподключение: нет сети", f"ждали {wait} сек.")
            return "no_network"
        action = cfg["autoconnect_action"]
        label = cfg["autoconnect_label"]
        if action == "last":
            st = _load_state()
            action, label = st.get("last_action", ""), st.get("last_label", "")
        if not action:
            _log_event("info", "Автоподключение: локация не выбрана", "")
            return "no_location"
        _log_event("info", "Автоподключение: проверка входа", _who_am_i())
        lic = await _cli_once(["license"], STATUS_TIMEOUT)
        if not lic["timeout"] and AUTH_RE.search(lic["output"]):
            Plugin._auth = False
            _log_event("warn", "Автоподключение пропущено: не выполнен вход", lic["output"][:500])
            await _toast("🔑 AdGuard: нужен вход", "Автоподключение пропущено")
            return "not_logged_in"
        if Plugin._login_proc is not None and Plugin._login_proc.poll() is None:
            _log_event("info", "Автоподключение пропущено: идёт вход", "")
            return "login"
        r = await _cli_once(["status"], STATUS_TIMEOUT)
        if not r["timeout"] and _parse_status(r["output"], r["code"]).get("connected"):
            return "already_connected"
        res = await self._do_action(action, label, source="autoconnect")
        if res.get("ok"):
            _save_state(desired="connected", gave_up=False)
            await _toast("✅ Автоподключение", (label or action)[:40])
            return "connected"
        await _toast("❌ Автоподключение", "См. Журнал")
        return "failed"

    # ---------- журнал ----------

    async def get_events(self) -> list:
        return list(reversed(_events()))            # новые сверху

    async def clear_events(self) -> list:
        _events().clear()
        _write_json("events.json", {"events": []})
        return []

    # ---------- IP через VPN ----------

    async def get_ip(self, force: bool = False) -> dict:
        c = _IP_CACHE
        if not force and c["data"] is not None and time.monotonic() - c["ts"] < IP_CACHE_SECONDS:
            return c["data"]
        fut = _INFLIGHT.get("__ip__")
        if fut is None or fut.done():
            fut = asyncio.ensure_future(asyncio.to_thread(_fetch_ip))
            _INFLIGHT["__ip__"] = fut
        data = await asyncio.shield(fut)
        c.update(ts=time.monotonic(), data=data)
        return data

    # ---------- обновление AdGuard VPN CLI ----------

    @_logged
    async def check_update(self, force: bool = False) -> dict:
        c = Plugin._update_cache
        if not force and c["data"] is not None and time.monotonic() - c["ts"] < UPDATE_CACHE_SECONDS:
            return dict(c["data"], plugin_version=_plugin_version())
        data = {"installed": "", "latest": "", "update_available": False, "error": None}
        if _cli_path():
            r = await _cli_once(["--version"], STATUS_TIMEOUT)
            v = _version_tuple(r["output"]) if not r["timeout"] else None
            data["installed"] = ".".join(map(str, v)) if v else ""
        try:
            rel = await asyncio.to_thread(_http_json, GITHUB_LATEST, 15)
            lv = _version_tuple(rel.get("tag_name", ""))
            data["latest"] = ".".join(map(str, lv)) if lv else ""
        except Exception as e:
            data["error"] = f"GitHub: {e}"[:200]
        iv, lv = _version_tuple(data["installed"]), _version_tuple(data["latest"])
        data["update_available"] = bool(iv and lv and lv > iv)
        if data["update_available"]:
            _log_event("info", f"Доступно обновление AdGuard {data['latest']}", f"установлено: {data['installed']}")
        elif data["error"]:
            _log_event("warn", "Проверка обновления: нет связи с GitHub", data["error"])
        elif force:
            _log_event("info", f"AdGuard {data['installed'] or '?'} — последняя версия", f"GitHub: {data['latest']}")
        c.update(ts=time.monotonic(), data=data)
        return dict(data, plugin_version=_plugin_version())

    @_logged
    async def start_update(self) -> dict:
        """Официальное обновление: `adguardvpn-cli update -y -v` (через встроенный скрипт, от пользователя)."""
        p = Plugin._update_proc
        if p and p.poll() is None:
            return await self.update_poll()
        if os.geteuid() == 0 and not _pw():
            return {"ok": False, "running": False, "message": "Не найден пользователь"}
        real = os.path.realpath(_bundled_script())
        if not os.path.isfile(real) or not _cli_path():
            return {"ok": False, "running": False, "message": "Нет скрипта или adguardvpn-cli"}
        Plugin._update_proc, _ = await self._launch(real, ["update"], "update.log")
        Plugin._update_logged = False
        _log_event("info", "Обновление AdGuard запущено", "adguardvpn-cli update -y -v")
        LOG.info("update started")
        return {"ok": True, "running": True, "message": "Обновление запущено", "output": ""}

    async def update_poll(self) -> dict:
        try:
            text = _strip_ansi(open(os.path.join(_log_dir(), "update.log"), encoding="utf-8",
                                    errors="replace").read())
        except Exception:
            text = ""
        body = "\n".join(text.splitlines()[1:]).strip()
        p = Plugin._update_proc
        running = bool(p and p.poll() is None)
        res = {"ok": True, "running": running, "output": body[-1500:], "message": ""}
        if p and not running:
            ok = p.returncode == 0 and not re.search(r"\b(error|failed)\b", body, re.IGNORECASE)
            res.update(ok=ok, message="Обновлено" if ok else "Ошибка обновления")
            Plugin._update_cache["ts"] = 0.0          # перечитать версию
            if not Plugin._update_logged:
                Plugin._update_logged = True
                _log_event("ok" if ok else "error", "AdGuard обновлён" if ok else _explain_error(body) + " (обновление)",
                           f"код: {p.returncode}\n{body}")
        return res

    async def _main(self):
        _setup_file_log()
        Plugin._watchdog_task = asyncio.ensure_future(self._watchdog())
        Plugin._auto_task = asyncio.ensure_future(self._autoconnect_safe())
        try:
            _log_event("info", f"Плагин {_plugin_version()} запущен", _who_am_i() + f"\nCLI: {_cli_path() or 'не найден'}")
        except Exception:
            LOG.exception("startup event")
        LOG.info(f"AdGuard VPN {_plugin_version()} loaded; euid={os.geteuid()} user={_target_user()} "
                 f"(по: {_USER_CACHE['how'] or '—'}) home={_user_home()} cli={_cli_path()}")

    async def _unload(self):
        for t in (Plugin._watchdog_task, Plugin._auto_task):
            if t and not t.done():
                t.cancel()
        LOG.info("AdGuard VPN plugin unloaded (VPN и скрипты не трогаем)")

    async def _uninstall(self):
        LOG.info("AdGuard VPN plugin uninstalled")
