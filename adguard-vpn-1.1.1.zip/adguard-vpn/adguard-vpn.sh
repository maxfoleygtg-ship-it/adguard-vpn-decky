#!/bin/bash
# Встроенный скрипт плагина AdGuard VPN.
#   adguard-vpn.sh slovakia | germany | sweden | kazakhstan | fastest | off | status | update
#   adguard-vpn.sh connect "<город, страна или ISO>"   — любая локация, например:
#   adguard-vpn.sh connect "New York"      adguard-vpn.sh connect "Kazakhstan"
# Без аргумента показывает меню (kdialog), как привычный скрипт.
# После connect/disconnect печатает `adguardvpn-cli status` (только чтение)
# между строками "=== status ===" и "status_code=N", чтобы плагин сразу
# показал статус и локацию в том же формате, что и обычный опрос статуса.

CLI="adguardvpn-cli"
if ! command -v "$CLI" >/dev/null 2>&1; then
  for p in /usr/local/bin/adguardvpn-cli /opt/adguardvpn_cli/adguardvpn-cli "$HOME/.local/bin/adguardvpn-cli"; do
    [ -x "$p" ] && CLI="$p" && break
  done
fi

[ -n "$ADGUARD_VPN_PIDFILE" ] && echo $$ > "$ADGUARD_VPN_PIDFILE" 2>/dev/null

print_status() {
  sleep "${1:-1}"
  echo "=== status ==="
  "$CLI" status 2>&1
  echo "status_code=$?"
}

connect_to() {
  # Имя локации — одним аргументом, в кавычках; не даём начать его с «-» (не станет опцией)
  case "$1" in
    ""|-*) echo "Недопустимое имя локации: '$1'"; return 2 ;;
  esac
  "$CLI" connect -l "$1" -y
}

CHOICE="$1"
if [ -z "$CHOICE" ]; then
  CHOICE=$(kdialog --menu "AdGuard VPN" "slovakia" "Подключить Slovakia" "germany" "Подключить Germany" "sweden" "Подключить Sweden" "kazakhstan" "Подключить Kazakhstan" "off" "Отключить" 2>/dev/null)
fi

case "$CHOICE" in
  slovakia)   connect_to "Slovakia";   rc=$?; print_status 2 ;;
  germany)    connect_to "Germany";    rc=$?; print_status 2 ;;
  sweden)     connect_to "Sweden";     rc=$?; print_status 2 ;;
  kazakhstan) connect_to "Kazakhstan"; rc=$?; print_status 2 ;;
  connect)    connect_to "$2";         rc=$?; [ $rc -ne 2 ] && print_status 2 ;;
  fastest)    "$CLI" connect -f -y;    rc=$?; print_status 2 ;;   # самая быстрая локация (CLI сам выбирает)
  update)     "$CLI" update -y -v;     rc=$? ;;                   # официальное обновление CLI, без вопросов
  off)        "$CLI" disconnect;       rc=$?; print_status 1 ;;
  status)     print_status 0; rc=0 ;;
  "")         echo "Ничего не выбрано"; rc=0 ;;
  *)          echo "Неизвестный пункт: $CHOICE (нужно: slovakia, germany, sweden, kazakhstan, fastest, connect <локация>, off, status, update)"; rc=2 ;;
esac
exit $rc
