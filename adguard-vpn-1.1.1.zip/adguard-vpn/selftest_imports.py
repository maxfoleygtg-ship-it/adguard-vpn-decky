#!/usr/bin/env python3
"""
Самопроверка 1.1.1: main.py должен загружаться в Python от Decky 3.3+, где НЕТ модулей
pty / tty / termios (из-за `import pty` бэкенд 1.1.0 не запускался вообще).
Запуск:  python3 selftest_imports.py   → «OK: main.py загружается без pty/tty/termios»
"""
import os, sys, types
for m in ("pty", "tty", "termios", "curses", "readline"):
    sys.modules[m] = None                      # import m → ModuleNotFoundError, как в Decky
here = os.path.dirname(os.path.abspath(__file__))
stub = types.ModuleType("decky")
import logging
stub.logger = logging.getLogger("selftest")
for k in ("DECKY_PLUGIN_DIR", "DECKY_PLUGIN_LOG_DIR", "DECKY_PLUGIN_SETTINGS_DIR", "DECKY_PLUGIN_RUNTIME_DIR"):
    setattr(stub, k, os.path.join("/tmp", "adguard-vpn-selftest") if k != "DECKY_PLUGIN_DIR" else here)
sys.modules.setdefault("decky", stub)
sys.path.insert(0, here)
import main                                     # noqa: E402
assert hasattr(main, "Plugin") and hasattr(main.Plugin, "login_start")
print("OK: main.py загружается без pty/tty/termios")
