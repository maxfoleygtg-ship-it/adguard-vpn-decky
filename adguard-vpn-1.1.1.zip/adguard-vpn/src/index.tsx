import {
  ButtonItem,
  DropdownItem,
  DialogButton,
  Field,
  Focusable,
  PanelSection,
  PanelSectionRow,
  Spinner,
  ToggleField,
  staticClasses,
} from "@decky/ui";
import { addEventListener, callable, definePlugin, removeEventListener, toaster } from "@decky/api";
import { useCallback, useEffect, useRef, useState } from "react";
import { FaShieldAlt } from "react-icons/fa";
import qrcode from "qrcode-generator";

// ---------------- Типы ответов бэкенда ----------------

type LocationId = "Slovakia" | "Germany" | "Sweden" | "Kazakhstan";
// "loc:<город/страна>" — любая локация из «Других» / «Избранного»
type Action = LocationId | "off" | "fastest" | `loc:${string}`;

interface VpnStatus {
  state: "connected" | "connecting" | "reconnecting" | "disconnected" | "unknown";
  connected: boolean;
  location: LocationId | null;
  location_text: string;
  raw: string;
  code: number;
  error: string | null;
  slow?: number; // CLI ответил, но дольше 10 сек. (медленная сеть)
}

interface RunResult {
  ok: boolean;
  message: string;
  output?: string;
  running?: boolean;
  status?: VpnStatus; // встроенный скрипт сразу сообщает `adguardvpn-cli status`
  warning?: string;
  error_label?: string;
}

interface AccountInfo {
  cli: boolean;
  logged_in: boolean | null;
  plan?: string;
  email?: string;
  raw: string;
  no_subscription?: boolean;
  timeout?: boolean;
  error?: string;
  until?: string; // ДД.ММ.ГГГГ
  renews?: boolean;
  devices?: number | null;
  traffic_left?: string;
  traffic_out?: boolean;
}

interface LoginState {
  ok: boolean;
  running?: boolean;
  url?: string;
  code?: string;
  seconds_left?: number;
  done?: boolean;
  error?: string | null;
  output?: string;
  message?: string;
}

interface LocRow {
  iso: string;
  country: string;
  city: string;
  ping: number | null;
}

interface LocationsResult {
  ok: boolean;
  source: "cli" | "fallback";
  locations: LocRow[];
  error: string | null;
  age?: number;
}

// ---------------- Бэкенд ----------------

const getStatus = callable<[], VpnStatus>("get_status");
const runAction = callable<[action: string, label: string], RunResult>("run_action");

interface Settings {
  autoconnect: boolean;
  autoconnect_action: string; // "last" | Action
  autoconnect_label: string;
  reconnect: boolean;
  last_action?: string;
  last_label?: string;
  plugin_version?: string;
}
interface IpInfo {
  ok: boolean;
  ip?: string;
  country?: string;
  city?: string;
  error?: string;
}
interface UpdateInfo {
  installed: string;
  latest: string;
  update_available: boolean;
  error: string | null;
  plugin_version: string;
}
interface UpdateState {
  ok: boolean;
  running: boolean;
  message: string;
  output?: string;
}
interface LogEvent {
  id: number;
  time: string;
  date: string;
  level: "info" | "ok" | "warn" | "error";
  summary: string;
  details: string;
}
const getSettings = callable<[], Settings>("get_settings");
const setSettings = callable<[changes: Partial<Settings>], Settings>("set_settings");
const getIp = callable<[force: boolean], IpInfo>("get_ip");
const checkUpdate = callable<[force: boolean], UpdateInfo>("check_update");
const startUpdate = callable<[], UpdateState>("start_update");
const updatePoll = callable<[], UpdateState>("update_poll");
const getEvents = callable<[], LogEvent[]>("get_events");
const clearEvents = callable<[], LogEvent[]>("clear_events");

// Промис с тайм-аутом: если бэкенд не запустился, вызовы Decky могут не вернуться никогда.
function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("timeout")), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      },
    );
  });
}
const BACKEND_LOG_DIR = "~/homebrew/logs/adguard-vpn/";

/** Короткое уведомление: заголовок 2–3 слова, одна строка текста. Подробности — в «📜 Журнал». */
function notify(title: string, body: string) {
  toaster.toast({ title, body: body.length > 42 ? body.slice(0, 40) + "…" : body, icon: <FaShieldAlt />, duration: 7000 });
}
const accountInfo = callable<[], AccountInfo>("account_info");
const getLocations = callable<[force: boolean], LocationsResult>("get_locations");
const getFavorites = callable<[], string[]>("get_favorites");
const setFavorite = callable<[key: string, on: boolean], string[]>("set_favorite");
const loginStart = callable<[], LoginState>("login_start");
const loginPoll = callable<[], LoginState>("login_poll");
const loginCancel = callable<[], LoginState>("login_cancel");
const loginSpeedup = callable<[], LoginState>("login_speedup");
interface SetupItem {
  id: string;
  ok: boolean;
  label: string;
  step: string;
  hint: string;
  required: boolean;
}
interface SetupResult {
  ok: boolean;
  only_login_missing: boolean;
  logged_in: boolean | null;
  items: SetupItem[];
  missing: SetupItem[];
}
const checkSetup = callable<[], SetupResult>("check_setup");
const logoutCall = callable<[], { ok: boolean; message: string }>("logout");

/** Ссылка для входа из вывода CLI: любая https-ссылка (CLI может дать зеркало со случайным доменом),
 *  в первую очередь та, где есть device_code / user_code. */
function extractLoginUrl(text?: string): string {
  const urls = (text ?? "").match(/https?:\/\/[^\s<>"'`]+/gi)?.map((u) => u.replace(/[.,;:)\]}'"]+$/, "")) ?? [];
  return urls.find((u) => /device_code|user_code/i.test(u)) ?? urls.find((u) => /^https:/i.test(u)) ?? urls[0] ?? "";
}

function qrDataUrl(text: string): string {
  try {
    const qr = qrcode(0, "M");
    qr.addData(text);
    qr.make();
    return qr.createDataURL(5, 2);
  } catch {
    return "";
  }
}

// ---------------- Проверка установки ----------------

/** Блок «⚠️ Установка не завершена». Ничего не показывает, если всё в порядке
 *  или не хватает только входа (для него внизу обычная кнопка «Войти»). */
function SetupWarning({ setup }: { setup: SetupResult | null }) {
  if (!setup || setup.ok || setup.only_login_missing || !setup.missing.length) return null;
  const steps = Array.from(new Set(setup.missing.map((i) => i.step)));
  return (
    <PanelSection title="⚠️ Установка не завершена">
      {setup.missing.map((i) => (
        <PanelSectionRow key={i.id}>
          <div style={{ fontSize: "12px", color: "#ffc82c" }}>
            • {i.label} <span style={{ opacity: 0.8 }}>(инструкция: {i.step})</span>
            {i.hint ? <div style={{ fontSize: "11px", opacity: 0.7, wordBreak: "break-word" }}>{i.hint}</div> : null}
          </div>
        </PanelSectionRow>
      ))}
      <PanelSectionRow>
        <div style={{ fontSize: "12px" }}>
          Запустите скрипт установки ещё раз на рабочем столе:{" "}
          <span style={{ fontFamily: "monospace" }}>bash ~/Downloads/install-adguard-vpn-decky.sh</span> — или
          смотрите инструкцию: {steps.join(", ")}.
        </div>
      </PanelSectionRow>
    </PanelSection>
  );
}

// ---------------- Подписка ----------------

/** «Premium до 01.05.2027» / «Premium, продление 01.05.2027» / «Free» / «✅» */
function planLabel(a: AccountInfo | null): string {
  if (!a?.plan) return "✅";
  const name = a.plan === "PREMIUM" ? "Premium" : a.plan === "FREE" ? "Free" : a.plan[0] + a.plan.slice(1).toLowerCase();
  if (a.until) return a.renews ? `${name}, продление ${a.until}` : `${name} до ${a.until}`;
  return name;
}
function planDetails(a: AccountInfo | null): string {
  if (!a) return "";
  const parts: string[] = [];
  if (a.devices) parts.push(`до ${a.devices} устройств`);
  if (a.traffic_out) parts.push("бесплатный трафик закончился");
  else if (a.traffic_left) parts.push(`осталось ${a.traffic_left}`);
  return parts.join(" · ");
}

// ---------------- Вход в аккаунт AdGuard ----------------

function AccountSection({ onChanged, forceShow }: { onChanged: () => void; forceShow: boolean }) {
  const [acc, setAcc] = useState<AccountInfo | null>(null);
  const [login, setLogin] = useState<LoginState | null>(null);
  const [busy, setBusy] = useState(false);
  const [advanced, setAdvanced] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);
  const mounted = useRef(true);

  const reloadAcc = useCallback(async () => {
    try {
      const a = await accountInfo();
      if (mounted.current) setAcc(a);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    reloadAcc();
    loginPoll()
      .then((st) => mounted.current && st.running && setLogin(st))
      .catch(() => undefined);
    return () => {
      mounted.current = false;
    };
  }, [reloadAcc]);

  useEffect(() => {
    if (forceShow) reloadAcc();
  }, [forceShow, reloadAcc]);

  // Пока идёт вход — опрашиваем каждые 3 секунды
  useEffect(() => {
    if (!login?.running) return;
    const t = setInterval(async () => {
      try {
        const st = await loginPoll();
        if (!mounted.current) return;
        setLogin(st);
        if (st.done) {
          notify("✅ Вход выполнен", "Аккаунт AdGuard");
          reloadAcc();
          onChanged();
        } else if (!st.running && st.error) {
          notify("❌ Вход не выполнен", "См. Журнал");
        }
      } catch {
        /* ignore */
      }
    }, 3000);
    return () => clearInterval(t);
  }, [login?.running, reloadAcc, onChanged]);

  const start = async () => {
    setBusy(true);
    try {
      let st: LoginState;
      try {
        st = await withTimeout(loginStart(), 40000);
      } catch {
        notify("❌ Вход", "Плагин не ответил");
        return;
      }
      if (!st.ok) notify("❌ Вход", "См. Журнал");
      setLogin(st);
      if (st.done) {
        reloadAcc();
        onChanged();
      }
    } finally {
      setBusy(false);
    }
  };

  // «Войти» показываем ВСЕГДА, кроме случая, когда CLI точно подтвердил вход
  // (1.0.7 прятал кнопку при «нет ответа» — на новом устройстве войти было нельзя).
  const loggedIn = acc?.logged_in === true && !forceShow;
  const unknown = !acc || (acc.cli && acc.logged_in === null);
  const showLogin = !loggedIn || !!login?.running;
  const loginUrl = login?.url || extractLoginUrl(login?.output);
  const mmss = (n?: number) => (n ? `${Math.floor(n / 60)}:${String(n % 60).padStart(2, "0")}` : "");

  return (
    <PanelSection title="Аккаунт AdGuard">
      {acc && !acc.cli && (
        <PanelSectionRow>
          <div style={{ fontSize: "12px", color: "#ffc82c" }}>
            adguardvpn-cli не установлен. Установите его по инструкции INSTALL_RU.md (шаг 1).
          </div>
        </PanelSectionRow>
      )}
      {loggedIn && (
        <>
          <PanelSectionRow>
            <Field label={acc?.email || "Вход выполнен"} focusable={true}>
              <span style={{ fontWeight: "bold", color: acc?.plan === "PREMIUM" ? "#ffc82c" : undefined }}>
                {planLabel(acc)}
              </span>
            </Field>
          </PanelSectionRow>
          {planDetails(acc) && (
            <PanelSectionRow>
              <div style={{ fontSize: "12px", opacity: 0.75 }}>{planDetails(acc)}</div>
            </PanelSectionRow>
          )}
        </>
      )}
      {acc?.no_subscription && (
        <PanelSectionRow>
          <div style={{ fontSize: "12px", color: "#ffc82c" }}>💳 Подписка закончилась или исчерпан лимит.</div>
        </PanelSectionRow>
      )}
      {showLogin && acc?.cli !== false && (
        <>
          {unknown && !login?.running && (
            <PanelSectionRow>
              <div style={{ fontSize: "12px", opacity: 0.85 }}>
                {!acc
                  ? "Проверяем аккаунт… (на медленной сети до минуты). Если вы ещё не входили — нажмите «Войти»."
                  : acc.error === "user_unknown"
                    ? "Не удалось определить пользователя Steam. Перезапустите Decky или устройство."
                    : acc.timeout
                      ? "AdGuard не ответил вовремя (медленная сеть), вход проверить не удалось. Если вы ещё не входили — нажмите «Войти»."
                      : "Не удалось проверить вход. Если вы ещё не входили — нажмите «Войти»."}
              </div>
            </PanelSectionRow>
          )}
          {!login?.running && (
            <PanelSectionRow>
              <ButtonItem layout="below" disabled={busy} onClick={start}>
                {busy ? "Запуск входа…" : "🔑 Войти в AdGuard"}
              </ButtonItem>
            </PanelSectionRow>
          )}
          {login?.running && (
            <>
              <PanelSectionRow>
                <div style={{ fontSize: "12px" }}>
                  Отсканируйте QR-код телефоном (или откройте ссылку в любом браузере) и войдите в аккаунт
                  AdGuard. Плагин сам увидит, что вход выполнен.
                </div>
              </PanelSectionRow>
              {loginUrl && (
                <PanelSectionRow>
                  <div style={{ display: "flex", justifyContent: "center", background: "#fff", padding: "6px", borderRadius: "6px" }}>
                    <img src={qrDataUrl(loginUrl)} style={{ width: "200px", height: "200px", imageRendering: "pixelated" }} />
                  </div>
                </PanelSectionRow>
              )}
              {login.code && (
                <PanelSectionRow>
                  <Field label="Код" focusable={true}>
                    <span style={{ fontSize: "20px", fontWeight: "bold", letterSpacing: "2px" }}>{login.code}</span>
                  </Field>
                </PanelSectionRow>
              )}
              {loginUrl && (
                <PanelSectionRow>
                  <div style={{ fontFamily: "monospace", fontSize: "11px", wordBreak: "break-all" }}>{loginUrl}</div>
                </PanelSectionRow>
              )}
              {!loginUrl && (
                <PanelSectionRow>
                  <div style={{ fontFamily: "monospace", fontSize: "11px", whiteSpace: "pre-wrap" }}>
                    {login.output || "Ждём ссылку от adguardvpn-cli… (на медленной сети до 1 минуты)"}
                  </div>
                </PanelSectionRow>
              )}
              {!!login.seconds_left && (
                <PanelSectionRow>
                  <div style={{ fontSize: "12px", opacity: 0.8 }}>Ссылка действует ещё {mmss(login.seconds_left)}</div>
                </PanelSectionRow>
              )}
              <PanelSectionRow>
                <ButtonItem layout="below" onClick={async () => setLogin(await loginSpeedup())}>
                  ✔️ Я вошёл — проверить сейчас
                </ButtonItem>
              </PanelSectionRow>
              <PanelSectionRow>
                <ButtonItem
                  layout="below"
                  onClick={async () => {
                    await loginCancel();
                    setLogin(await loginPoll());
                  }}
                >
                  ✖ Отменить вход
                </ButtonItem>
              </PanelSectionRow>
            </>
          )}
          {login && !login.running && login.error && (
            <PanelSectionRow>
              <div style={{ fontSize: "12px", color: "#ff6b6b" }}>Вход не выполнен: {login.error}</div>
            </PanelSectionRow>
          )}
        </>
      )}
      <PanelSectionRow>
        <ToggleField label="Подробнее об аккаунте" checked={advanced} onChange={(v: boolean) => setAdvanced(v)} />
      </PanelSectionRow>
      {advanced && (
        <>
          <PanelSectionRow>
            <ButtonItem layout="below" onClick={reloadAcc}>
              🔄 Проверить аккаунт
            </ButtonItem>
          </PanelSectionRow>
          {loggedIn && (
            <PanelSectionRow>
              <ButtonItem
                layout="below"
                onClick={async () => {
                  if (!confirmLogout) {
                    setConfirmLogout(true);
                    setTimeout(() => mounted.current && setConfirmLogout(false), 5000);
                    return;
                  }
                  setConfirmLogout(false);
                  const r = await logoutCall();
                  notify(r.ok ? "🚪 Выход" : "❌ Выход", r.ok ? "Вы вышли из аккаунта" : "См. Журнал");
                  reloadAcc();
                  onChanged();
                }}
              >
                {confirmLogout ? "Нажмите ещё раз, чтобы выйти" : "🚪 Выйти из аккаунта"}
              </ButtonItem>
            </PanelSectionRow>
          )}
          <PanelSectionRow>
            <div style={{ fontFamily: "monospace", fontSize: "11px", whiteSpace: "pre-wrap", opacity: 0.8 }}>
              {acc?.raw || "—"}
            </div>
          </PanelSectionRow>
        </>
      )}
    </PanelSection>
  );
}


// ---------------- Настройки: автоподключение, переподключение, обновление ----------------

function SettingsSection(props: { options: { data: string; label: string }[]; onUpdated: () => void }) {
  const [cfg, setCfg] = useState<Settings | null>(null);
  const [upd, setUpd] = useState<UpdateInfo | null>(null);
  const [updState, setUpdState] = useState<UpdateState | null>(null);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    getSettings().then((c) => mounted.current && setCfg(c)).catch(() => undefined);
    checkUpdate(false).then((u) => mounted.current && setUpd(u)).catch(() => undefined);
    updatePoll().then((u) => mounted.current && u.running && setUpdState(u)).catch(() => undefined);
    return () => {
      mounted.current = false;
    };
  }, []);

  // Пока идёт обновление — опрос раз в 3 сек.
  useEffect(() => {
    if (!updState?.running) return;
    const t = setInterval(async () => {
      try {
        const u = await updatePoll();
        if (!mounted.current) return;
        setUpdState(u);
        if (!u.running) {
          notify(u.ok ? "✅ AdGuard обновлён" : "❌ Обновление", u.ok ? "Вход сохранён" : "См. Журнал");
          setUpd(await checkUpdate(true));
          props.onUpdated();
        }
      } catch {
        /* ignore */
      }
    }, 3000);
    return () => clearInterval(t);
  }, [updState?.running]);

  const change = async (c: Partial<Settings>) => {
    setCfg((prev) => (prev ? { ...prev, ...c } : prev));
    try {
      const n = await setSettings(c);
      if (mounted.current) setCfg(n);
    } catch {
      notify("❌ Настройки", "Не сохранены");
    }
  };
  const lastLabel = cfg?.last_label ? ` (${cfg.last_label})` : "";
  const options = [{ data: "last", label: `Последняя${lastLabel}` }, ...props.options];
  const selected = options.some((o) => o.data === cfg?.autoconnect_action) ? cfg?.autoconnect_action : "last";

  return (
    <PanelSection title="Настройки">
      <PanelSectionRow>
        <ToggleField
          label="Подключаться при запуске"
          description="Когда включается Decky (после загрузки)"
          checked={!!cfg?.autoconnect}
          disabled={!cfg}
          onChange={(v: boolean) => change({ autoconnect: v })}
        />
      </PanelSectionRow>
      {cfg?.autoconnect && (
        <PanelSectionRow>
          <DropdownItem
            label="Куда"
            rgOptions={options}
            selectedOption={selected}
            onChange={(o) => change({ autoconnect_action: o.data, autoconnect_label: o.data === "last" ? "" : String(o.label) })}
          />
        </PanelSectionRow>
      )}
      <PanelSectionRow>
        <ToggleField
          label="Переподключать при обрыве"
          description="Проверка раз в 30 сек., до 3 попыток"
          checked={!!cfg?.reconnect}
          disabled={!cfg}
          onChange={(v: boolean) => change({ reconnect: v })}
        />
      </PanelSectionRow>
      {upd?.update_available && !updState?.running && (
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            label={`Доступно обновление AdGuard ${upd.latest}`}
            description={`Установлено: ${upd.installed}`}
            onClick={async () => setUpdState(await startUpdate())}
          >
            ⬆️ Обновить
          </ButtonItem>
        </PanelSectionRow>
      )}
      {updState?.running && (
        <PanelSectionRow>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "13px" }}>
            <Spinner style={{ width: "18px", height: "18px" }} />
            <span>Обновление AdGuard…</span>
          </div>
        </PanelSectionRow>
      )}
      {updState && !updState.running && updState.message && (
        <PanelSectionRow>
          <div style={{ fontSize: "12px", color: updState.ok ? "#59bf40" : "#ff6b6b" }}>
            {updState.ok ? "✅" : "❌"} {updState.message}
          </div>
        </PanelSectionRow>
      )}
      {upd && !upd.update_available && upd.installed && (
        <PanelSectionRow>
          <div style={{ fontSize: "11px", opacity: 0.55 }}>AdGuard VPN CLI {upd.installed} — последняя версия</div>
        </PanelSectionRow>
      )}
    </PanelSection>
  );
}

// ---------------- Журнал событий ----------------

const LEVEL_ICON: Record<LogEvent["level"], string> = { ok: "✅", info: "ℹ️", warn: "⚠️", error: "❌" };

function EventLog({ version }: { version: number }) {
  const [open, setOpen] = useState(false);
  const [onlyErr, setOnlyErr] = useState(false);
  const [items, setItems] = useState<LogEvent[]>([]);
  const [expanded, setExpanded] = useState<number | null>(null);

  useEffect(() => {
    if (!open) return;
    const load = () => getEvents().then(setItems).catch(() => undefined);
    load();
    const t = setInterval(load, 3000); // журнал обновляется сам, даже пока идёт действие
    return () => clearInterval(t);
  }, [open, version]);

  const shown = onlyErr ? items.filter((e) => e.level === "error" || e.level === "warn") : items;
  return (
    <>
      <PanelSectionRow>
        <ToggleField label="📜 Журнал" description="Последние 50 событий" checked={open} onChange={(v: boolean) => setOpen(v)} />
      </PanelSectionRow>
      {open && (
        <>
          <PanelSectionRow>
            <ToggleField label="Только ошибки" checked={onlyErr} onChange={(v: boolean) => setOnlyErr(v)} />
          </PanelSectionRow>
          {shown.length === 0 && (
            <PanelSectionRow>
              <div style={{ fontSize: "12px", opacity: 0.6 }}>Событий нет</div>
            </PanelSectionRow>
          )}
          {shown.map((e) => (
            <PanelSectionRow key={e.id}>
              <Focusable
                onActivate={() => setExpanded(expanded === e.id ? null : e.id)}
                onClick={() => setExpanded(expanded === e.id ? null : e.id)}
                style={{ width: "100%", padding: "2px 0" }}
              >
                <div
                  style={{
                    display: "flex", gap: "6px", fontSize: "12px", alignItems: "baseline",
                    color: e.level === "error" ? "#ff6b6b" : e.level === "warn" ? "#ffc82c" : undefined,
                  }}
                >
                  <span>{LEVEL_ICON[e.level]}</span>
                  <span style={{ opacity: 0.6, fontFamily: "monospace" }}>{e.time}</span>
                  <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: expanded === e.id ? "normal" : "nowrap" }}>
                    {e.summary}
                  </span>
                </div>
                {expanded === e.id && (
                  <div
                    style={{
                      fontFamily: "monospace", fontSize: "10px", whiteSpace: "pre-wrap", wordBreak: "break-word",
                      maxHeight: "180px", overflowY: "auto", opacity: 0.8, marginTop: "4px",
                      background: "rgba(255,255,255,0.05)", padding: "4px", borderRadius: "4px",
                    }}
                  >
                    {e.date} {e.time}
                    {"\n"}
                    {e.details || "—"}
                  </div>
                )}
              </Focusable>
            </PanelSectionRow>
          ))}
          {items.length > 0 && (
            <PanelSectionRow>
              <ButtonItem
                layout="below"
                onClick={async () => {
                  setItems(await clearEvents());
                  setExpanded(null);
                }}
              >
                🗑 Очистить журнал
              </ButtonItem>
            </PanelSectionRow>
          )}
        </>
      )}
    </>
  );
}

// ---------------- Настройки (localStorage) ----------------

const LS = "adguard-vpn.";
// 1.0.9: режим «Через Steam» удалён — старые настройки просто стираем
try {
  ["useSteam", "shortcutId"].forEach((k) => localStorage.removeItem(LS + k));
} catch {
  /* нет localStorage — не страшно */
}
const load = <T,>(k: string, d: T): T => {
  try {
    const v = localStorage.getItem(LS + k);
    return v === null ? d : (JSON.parse(v) as T);
  } catch {
    return d;
  }
};
const save = (k: string, v: unknown) => {
  try {
    localStorage.setItem(LS + k, JSON.stringify(v));
  } catch {
    /* ignore */
  }
};

// ---------------- Локации ----------------

// 4 фиксированные кнопки сверху. iso — чтобы брать пинг из list-locations.
const LOCATIONS: { id: LocationId; label: string; flag: string; iso: string }[] = [
  { id: "Slovakia", label: "Словакия", flag: "🇸🇰", iso: "SK" },
  { id: "Germany", label: "Германия", flag: "🇩🇪", iso: "DE" },
  { id: "Sweden", label: "Швеция", flag: "🇸🇪", iso: "SE" },
  { id: "Kazakhstan", label: "Казахстан", flag: "🇰🇿", iso: "KZ" },
];
const FIXED_ISO = new Set(LOCATIONS.map((l) => l.iso));
const POLL_MS = 4000;

// Пинг активной локации ЗАМОРОЖЕН на значении в момент выбора (так понят запрос).
// Чтобы пинг обновлялся вживую раз в минуту, поставьте true и пересоберите.
const LIVE_ACTIVE_PING = false;
const PING_POLL_MS = 60000; // используется только при LIVE_ACTIVE_PING = true

const COUNTRY_RU: Record<string, string> = {
  AE: "ОАЭ", AR: "Аргентина", AT: "Австрия", AU: "Австралия", BE: "Бельгия", BG: "Болгария", BR: "Бразилия",
  CA: "Канада", CH: "Швейцария", CL: "Чили", CN: "Китай", CO: "Колумбия", CY: "Кипр", CZ: "Чехия",
  DE: "Германия", DK: "Дания", EE: "Эстония", EG: "Египет", ES: "Испания", FI: "Финляндия", FR: "Франция",
  GB: "Великобритания", GR: "Греция", HK: "Гонконг", HR: "Хорватия", HU: "Венгрия", ID: "Индонезия",
  IE: "Ирландия", IL: "Израиль", IN: "Индия", IR: "Иран", IS: "Исландия", IT: "Италия", JP: "Япония",
  KH: "Камбоджа", KR: "Южная Корея", KZ: "Казахстан", LT: "Литва", LU: "Люксембург", LV: "Латвия",
  MD: "Молдова", MX: "Мексика", MY: "Малайзия", NG: "Нигерия", NL: "Нидерланды", NO: "Норвегия",
  NP: "Непал", NZ: "Новая Зеландия", PE: "Перу", PH: "Филиппины", PK: "Пакистан", PL: "Польша",
  PT: "Португалия", RO: "Румыния", RS: "Сербия", RU: "Россия", SA: "Саудовская Аравия", SE: "Швеция",
  SG: "Сингапур", SK: "Словакия", TH: "Таиланд", TR: "Турция", TW: "Тайвань", UA: "Украина", US: "США",
  VN: "Вьетнам", ZA: "ЮАР", AL: "Албания", EC: "Эквадор",
};
const CITY_RU: Record<string, string> = {
  Frankfurt: "Франкфурт", Berlin: "Берлин", Barcelona: "Барселона", Madrid: "Мадрид", Paris: "Париж",
  Marseille: "Марсель", London: "Лондон", Manchester: "Манчестер", Rome: "Рим", Milan: "Милан",
  Palermo: "Палермо", Vancouver: "Ванкувер", Montreal: "Монреаль", Toronto: "Торонто",
  "New York": "Нью-Йорк", Boston: "Бостон", Miami: "Майами", Dallas: "Даллас", Phoenix: "Финикс",
  Chicago: "Чикаго", Seattle: "Сиэтл", Denver: "Денвер", Atlanta: "Атланта", "Las Vegas": "Лас-Вегас",
  "Silicon Valley": "Кремниевая долина", "Los Angeles": "Лос-Анджелес",
};

const flagOf = (iso: string) =>
  /^[A-Z]{2}$/.test(iso) ? String.fromCodePoint(...[...iso].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65)) : "🌐";
const normCity = (s: string) => s.toUpperCase().replace(/\(VIRTUAL\)/g, "").trim();
const locKey = (r: LocRow) => `${r.iso}|${r.city}`;
const fixedKey = (id: LocationId) => `fixed:${id}`;

function citiesOf(rows: LocRow[], iso: string) {
  return rows.filter((r) => r.iso === iso);
}
/** Что передать в `adguardvpn-cli connect -l`: город, если городов в стране несколько, иначе страну. */
function targetOf(r: LocRow, rows: LocRow[]): string {
  if (!r.city || citiesOf(rows, r.iso).length <= 1) return r.country;
  return r.city;
}
function labelOf(r: LocRow, rows: LocRow[]): string {
  const country = COUNTRY_RU[r.iso] ?? r.country;
  const virtual = /virtual/i.test(r.city) ? " (вирт.)" : "";
  if (r.city && citiesOf(rows, r.iso).length > 1) {
    const city = r.city.replace(/\s*\(virtual\)/i, "");
    return `${country} — ${CITY_RU[city] ?? city}${virtual}`;
  }
  return country + virtual;
}

function pingColor(ms: number): string {
  if (ms < 80) return "#59bf40";
  if (ms < 150) return "#ffc82c";
  return "#ff6b6b";
}

function PingBadge({ ms, frozen }: { ms: number | null | undefined; frozen?: boolean }) {
  if (ms === null || ms === undefined) return <span style={{ fontSize: "12px", opacity: 0.5 }}>—</span>;
  return (
    <span style={{ fontSize: "12px", color: pingColor(ms), whiteSpace: "nowrap" }}>
      {frozen ? "📌 " : ""}
      {ms} мс
    </span>
  );
}

/** Строка в «Избранном» / «Других»: кнопка подключения + звёздочка «В избранное». */
function LocRowItem(props: {
  label: string;
  flag: string;
  ms: number | null | undefined;
  frozen: boolean;
  active: boolean;
  fav: boolean;
  disabled: boolean;
  onConnect: () => void;
  onFav: () => void;
}) {
  return (
    <PanelSectionRow>
      <Focusable style={{ display: "flex", gap: "6px", alignItems: "stretch", width: "100%" }} flow-children="horizontal">
        <DialogButton
          style={{
            flex: 1, minWidth: 0, padding: "6px 10px", display: "flex",
            justifyContent: "space-between", alignItems: "center", gap: "6px",
          }}
          disabled={props.disabled}
          onClick={props.onConnect}
        >
          <span
            style={{
              overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", textAlign: "left",
              ...(props.active ? { color: "#59bf40", fontWeight: "bold" } : {}),
            }}
          >
            {props.active ? "✅" : props.flag} {props.label}
          </span>
          <PingBadge ms={props.ms} frozen={props.frozen} />
        </DialogButton>
        <DialogButton
          style={{ width: "44px", minWidth: "44px", padding: 0, color: props.fav ? "#ffc82c" : undefined }}
          onClick={props.onFav}
        >
          {props.fav ? "★" : "☆"}
        </DialogButton>
      </Focusable>
    </PanelSectionRow>
  );
}

function statusLabel(s: VpnStatus | null): string {
  if (!s) return "Проверка…";
  if (s.error === "cli_not_found") return "adguardvpn-cli не найден";
  if (s.error === "not_logged_in") return "🔒 Не авторизован";
  if (s.error === "no_subscription") return "💳 Нет подписки / лимит";
  if (s.error === "timeout") return "⏳ Нет ответа (медленная сеть?)";
  if (s.error === "user_unknown") return "Не найден пользователь";
  if (s.error === "not_configured") return "⚙️ AdGuard ещё не настроен";
  if (s.error) return "Ошибка чтения статуса";
  switch (s.state) {
    case "connected":
      return "🟢 Включено";
    case "connecting":
      return "🟡 Подключение…";
    case "reconnecting":
      return "🟡 Переподключение…";
    case "disconnected":
      return "🔴 Отключено";
    default:
      return "Неизвестно";
  }
}

function Content() {
  const [status, setStatus] = useState<VpnStatus | null>(null);
  // Последний выбор: key ("fixed:Slovakia" или "KZ|Astana") и подпись — на случай, если CLI не сообщил локацию (код 10)
  const [lastSel, setLastSel] = useState<{ key: string; label: string } | null>(load("lastSel", null));
  // Пинг активной локации, замороженный в момент выбора
  const [frozen, setFrozen] = useState<{ key: string; ms: number | null } | null>(load("frozenPing", null));
  const [busy, setBusy] = useState<string | null>(null);
  const [lastError, setLastError] = useState<string>("");
  const [ip, setIp] = useState<IpInfo | null>(null);
  const [logVer, setLogVer] = useState(0);
  const [pluginVer, setPluginVer] = useState<string>("");
  const [backendDead, setBackendDead] = useState(false);
  const [busySince, setBusySince] = useState(0);
  const [, setTick] = useState(0);
  const [locs, setLocs] = useState<LocationsResult | null>(null);
  const [favs, setFavs] = useState<string[]>([]);
  const [othersOpen, setOthersOpen] = useState(false);
  const mounted = useRef(true);
  const busyRef = useRef(false);
  const [setup, setSetup] = useState<SetupResult | null>(null);
  // Проверка установки: при открытии панели, после входа и по кнопке «Обновить»
  const recheck = useCallback(async () => {
    try {
      const r = await checkSetup();
      if (mounted.current) setSetup(r);
    } catch {
      /* старый бэкенд / ошибка — блок просто не показываем */
    }
  }, []);
  useEffect(() => {
    recheck();
  }, [recheck]);

  // ---- внешний IP (через VPN): при открытии, после действий, по «Обновить»; кеш бэкенда 60 сек. ----
  const loadIp = useCallback(async (force = false) => {
    try {
      const r = await getIp(force);
      if (mounted.current) setIp(r);
    } catch {
      /* ignore */
    }
  }, []);
  useEffect(() => {
    loadIp();
    // Проверка, что бэкенд вообще запустился: get_settings отвечает мгновенно (без adguardvpn-cli)
    let stop = false;
    const ping = async () => {
      try {
        const c = await withTimeout(getSettings(), 8000);
        if (stop || !mounted.current) return;
        setPluginVer(c.plugin_version ?? "");
        setBackendDead(false);
      } catch {
        if (!stop && mounted.current) setBackendDead(true);
      }
    };
    ping();
    const t = setInterval(ping, 15000);
    return () => {
      stop = true;
      clearInterval(t);
    };
  }, [loadIp]);

  // ---- статус: всегда, только чтение (adguardvpn-cli status) ----
  // Один запрос за раз: на медленной сети `status` может идти 30+ сек., опрос раз в 4 сек. не копит запросы.
  const statusInFlight = useRef(false);
  const refresh = useCallback(async () => {
    if (statusInFlight.current) return;
    statusInFlight.current = true;
    try {
      const s = await getStatus();
      // «Нет ответа» не затирает последний настоящий статус (кроме «Проверка…»)
      if (mounted.current) setStatus((prev) => (s.error === "timeout" && prev && !prev.error ? prev : s));
    } catch (e) {
      if (mounted.current)
        setStatus({ state: "unknown", connected: false, location: null, location_text: "", raw: String(e), code: -3, error: "backend" });
    } finally {
      statusInFlight.current = false;
    }
  }, []);

  const onAccountChanged = useCallback(() => {
    refresh();
    recheck();
    setLogVer((v) => v + 1);
  }, [refresh, recheck]);

  useEffect(() => {
    mounted.current = true;
    refresh();
    // Опрос статуса идёт и во время действия (отдельно от очереди команд бэкенда)
    const t = setInterval(() => refresh(), POLL_MS);
    return () => {
      mounted.current = false;
      clearInterval(t);
    };
  }, [refresh]);

  // ---- локации и пинг (только чтение: adguardvpn-cli list-locations, кеш бэкенда 45 сек.) ----
  // Без постоянного опроса: при открытии панели, при открытии «Других» и по кнопке «Обновить».
  const loadLocations = useCallback(async (force = false) => {
    try {
      const r = await getLocations(force);
      if (mounted.current) setLocs((prev) => (r.error === "timeout" && prev?.ok ? prev : r));
    } catch {
      /* бэкенд недоступен — пинг просто не показываем */
    }
  }, []);

  useEffect(() => {
    loadLocations();
    getFavorites()
      .then((f) => mounted.current && setFavs(f))
      .catch(() => {});
    if (!LIVE_ACTIVE_PING) return;
    const t = setInterval(() => !busyRef.current && loadLocations(), PING_POLL_MS);
    return () => clearInterval(t);
  }, [loadLocations]);

  const toggleFav = async (key: string) => {
    const on = !favs.includes(key);
    setFavs((f) => (on ? [...f, key] : f.filter((k) => k !== key)));
    try {
      const f = await setFavorite(key, on);
      if (mounted.current) setFavs(f);
    } catch (e) {
      notify("❌ Избранное", "Не сохранено");
    }
  };

  // Несколько быстрых проверок статуса сразу после действия
  const burstRefresh = () => {
    [1500, 4000, 8000].forEach((ms) => setTimeout(() => mounted.current && refresh(), ms));
  };

  // ---- действия ----
  const doAction = async (action: Action, sel?: { key: string; label: string; ms: number | null }) => {
    if (busyRef.current && action === "off") {
      // Во время подключения «Отключить» = отмена: бэкенд убивает зависший connect и отключает VPN
      notify("⛔ Отмена", "Останавливаю подключение");
      setBusy("Отмена и отключение…");
      try {
        await withTimeout(runAction("off", ""), 120000);
      } catch {
        /* результат придёт в основном вызове */
      }
      setLogVer((v) => v + 1);
      refresh();
      return;
    }
    if (busyRef.current) return;
    const locLabel = sel?.label ?? LOCATIONS.find((l) => l.id === action)?.label;
    const remember = () => {
      if (!sel) return;
      const ls = { key: sel.key, label: sel.label };
      setLastSel(ls);
      save("lastSel", ls);
      const fz = { key: sel.key, ms: sel.ms };
      setFrozen(fz);
      save("frozenPing", fz);
    };
    busyRef.current = true;
    setBusySince(Date.now());
    setBusy(action === "off" ? "Отключение…" : `Подключение: ${locLabel}…`);
    setTimeout(() => mounted.current && setLogVer((v) => v + 1), 800);
    try {
      // Бэкенд сам убивает зависший connect через 150 с; 200 с — страховка интерфейса
      const r = await withTimeout(runAction(action, sel?.label ?? locLabel ?? ""), 200000);
      if (mounted.current) {
        if (r.status) setStatus(r.status); // статус сразу, не дожидаясь следующего опроса
        setLastError(r.ok ? "" : r.error_label || "Ошибка");
      }
      if (r.ok && action !== "off" && action !== "fastest") remember();
      if (!r.ok) {
        const short = (r.error_label || "Ошибка").replace(/^Ошибка: /, "");
        notify("❌ " + short.charAt(0).toUpperCase() + short.slice(1), "См. Журнал");
      }
      else if (action === "off") notify("⛔ VPN", "VPN отключён");
      else notify(`✅ ${action === "fastest" ? "Самая быстрая" : locLabel ?? "VPN"}`, "VPN подключён");
      if (r.ok && action !== "off") {
        setTimeout(async () => {
          try {
            const s = await getStatus();
            if (mounted.current) setStatus(s);
            if (s.state === "disconnected") notify("⚠️ VPN отключился", "Попробуйте ещё раз");
          } catch {
            /* ignore */
          }
        }, 20000);
      }
    } catch (e) {
      notify("❌ Ошибка", "Плагин не ответил");
      if (mounted.current)
        setLastError(String(e).includes("timeout") ? "Ошибка: плагин не ответил" : `Ошибка: ${String(e).slice(0, 60)}`);
    } finally {
      busyRef.current = false;
      if (mounted.current) {
        setBusy(null);
        refresh();
        burstRefresh();
        setLogVer((v) => v + 1);
        setTimeout(() => mounted.current && loadIp(true), 3000);
      }
    }
  };

  const connected = !!status?.connected;
  const isBusy = busy !== null;
  useEffect(() => {
    if (!isBusy) return;
    const t = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, [isBusy]);
  const rows = locs?.locations ?? [];
  const statusCity = connected ? normCity(status?.location_text || "") : "";
  const otherRows = rows.filter((r) => !FIXED_ISO.has(r.iso));
  // Активная локация: по городу из status; если CLI его не сообщил (код 10) — последний выбор
  const matchedOther = statusCity ? otherRows.find((r) => normCity(r.city) === statusCity) : undefined;
  const activeKey: string | null = !connected
    ? null
    : status?.location
      ? fixedKey(status.location)
      : matchedOther
        ? locKey(matchedOther)
        : statusCity
          ? null
          : lastSel?.key ?? null;
  const fixedActive = LOCATIONS.find((l) => fixedKey(l.id) === activeKey);
  const curLabel = fixedActive
    ? fixedActive.label
    : matchedOther
      ? labelOf(matchedOther, rows)
      : activeKey && lastSel?.key === activeKey
        ? lastSel.label
        : status?.location_text;

  // Пинг фиксированной кнопки: у активной — город подключения, иначе самый быстрый город страны
  const livePingFixed = (l: (typeof LOCATIONS)[number]): number | null => {
    const cs = citiesOf(rows, l.iso).filter((r) => r.ping !== null);
    if (!cs.length) return null;
    const conn = activeKey === fixedKey(l.id) ? cs.find((r) => normCity(r.city) === statusCity) : undefined;
    return conn ? conn.ping : Math.min(...cs.map((r) => r.ping as number));
  };
  // У активной локации показываем замороженное значение (если LIVE_ACTIVE_PING = false)
  const shownPing = (key: string, live: number | null): { ms: number | null; frozen: boolean } => {
    if (!LIVE_ACTIVE_PING && key === activeKey && frozen?.key === key && frozen.ms !== null)
      return { ms: frozen.ms, frozen: true };
    return { ms: live, frozen: false };
  };

  // Самая быстрая по оценке list-locations (сам выбор при подключении делает CLI: connect -f)
  const fastest = rows.filter((r) => r.ping !== null).sort((a, b) => (a.ping as number) - (b.ping as number))[0];
  // Варианты для автоподключения: самая быстрая, 4 кнопки, избранное
  const autoOptions = [
    { data: "fastest", label: "⚡ Самая быстрая" },
    ...LOCATIONS.map((l) => ({ data: l.id as string, label: `${l.flag} ${l.label}` })),
    ...otherRows
      .filter((r) => favs.includes(locKey(r)))
      .map((r) => ({ data: `loc:${targetOf(r, rows)}`, label: `⭐ ${labelOf(r, rows)}` })),
  ];

  const sortRows = (a: LocRow, b: LocRow) =>
    a.ping !== null && b.ping !== null ? a.ping - b.ping : labelOf(a, rows).localeCompare(labelOf(b, rows), "ru");
  const favRows = otherRows.filter((r) => favs.includes(locKey(r))).sort(sortRows);
  const restRows = otherRows.filter((r) => !favs.includes(locKey(r))).sort(sortRows);
  const rowItem = (r: LocRow) => {
    const key = locKey(r);
    const label = labelOf(r, rows);
    const p = shownPing(key, r.ping);
    return (
      <LocRowItem
        key={key}
        label={label}
        flag={flagOf(r.iso)}
        ms={p.ms}
        frozen={p.frozen}
        active={key === activeKey}
        fav={favs.includes(key)}
        disabled={isBusy}
        onConnect={() => doAction(`loc:${targetOf(r, rows)}`, { key, label, ms: r.ping })}
        onFav={() => toggleFav(key)}
      />
    );
  };
  const pingNote = locs?.source === "cli"
    ? LIVE_ACTIVE_PING
      ? "Пинг — оценка AdGuard (list-locations), обновляется раз в минуту"
      : "Пинг — оценка AdGuard (list-locations). 📌 — значение на момент выбора"
    : locs?.error === "not_logged_in"
      ? "Пинг недоступен: войдите в аккаунт AdGuard"
      : locs?.error === "timeout"
        ? "Пинг недоступен: AdGuard не ответил (медленная сеть). Нажмите «Обновить» в «Дополнительно»"
      : locs?.error === "cli_not_found"
        ? "Пинг недоступен: adguardvpn-cli не найден"
        : locs
          ? "Пинг недоступен"
          : "Пинг: измеряется…";

  return (
    <>
      {backendDead && (
        <PanelSection title="❌ Бэкенд плагина не запустился">
          <PanelSectionRow>
            <div style={{ fontSize: "12px", color: "#ff6b6b" }}>
              Панель не получает ответов от Python-части плагина. Перезапустите Decky (или устройство), а если не
              поможет — переустановите плагин. Лог: {BACKEND_LOG_DIR} и ~/homebrew/services/PluginLoader / journalctl -u plugin_loader.
            </div>
          </PanelSectionRow>
        </PanelSection>
      )}
      {/* 1. Статус — всегда сверху, обновляется сам */}
      <PanelSection title="Статус">
        <PanelSectionRow>
          <Field label="VPN" focusable={true}>
            <span style={{ fontWeight: "bold" }}>{backendDead && !status ? "❌ Бэкенд не запустился" : statusLabel(status)}</span>
          </Field>
        </PanelSectionRow>
        <PanelSectionRow>
          <Field label="Локация" focusable={true}>
            {connected ? (
              <span style={{ color: "#59bf40", fontWeight: "bold" }}>
                {curLabel || "неизвестно"}
                {status?.location_text && curLabel !== status.location_text ? ` (${status.location_text})` : ""}
              </span>
            ) : (
              "—"
            )}
          </Field>
        </PanelSectionRow>
        <PanelSectionRow>
          <Field label="IP" focusable={true}>
            <span style={{ fontSize: "13px" }}>
              {ip?.ok ? `${ip.ip} (${COUNTRY_RU[ip.country ?? ""] ?? ip.country ?? "?"})` : ip ? "не определён" : "…"}
            </span>
          </Field>
        </PanelSectionRow>
        {lastError && (
          <PanelSectionRow>
            <div style={{ fontSize: "12px", color: "#ff6b6b" }}>❌ {lastError} · см. «📜 Журнал»</div>
          </PanelSectionRow>
        )}
        {status?.error === "not_logged_in" && (
          <PanelSectionRow>
            <div style={{ fontSize: "12px", color: "#ffc82c" }}>Войдите в аккаунт: раздел «Аккаунт AdGuard» внизу</div>
          </PanelSectionRow>
        )}
        {status?.error === "timeout" && (
          <PanelSectionRow>
            <div style={{ fontSize: "12px", color: "#ffc82c" }}>
              adguardvpn-cli не ответил за 75 сек. Обычно это медленная сеть: при каждом запуске он сначала
              связывается с серверами AdGuard. Плагин продолжает проверять сам. Если вы ещё не входили —
              нажмите «🔑 Войти в AdGuard» внизу.
            </div>
          </PanelSectionRow>
        )}
        {status?.error === "user_unknown" && (
          <PanelSectionRow>
            <div style={{ fontSize: "12px", color: "#ffc82c" }}>
              Плагин не смог определить пользователя Steam. Перезапустите Decky (или устройство).
            </div>
          </PanelSectionRow>
        )}
        {status?.error === "not_configured" && (
          <PanelSectionRow>
            <div style={{ fontSize: "12px", color: "#ffc82c" }}>
              AdGuard ещё не настроен: CLI задаёт вопрос первого запуска. Плагин ответил «нет» сам; если
              сообщение не пропало — выполните в терминале: adguardvpn-cli config set-crash-reporting off
            </div>
          </PanelSectionRow>
        )}
        {!!status?.slow && !status.error && (
          <PanelSectionRow>
            <div style={{ fontSize: "11px", opacity: 0.7 }}>adguardvpn-cli отвечает медленно ({Math.round(status.slow)} сек.) — сеть медленная</div>
          </PanelSectionRow>
        )}
        {isBusy && (
          <PanelSectionRow>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <Spinner style={{ width: "20px", height: "20px" }} />
              <span>
                {busy}
                {busySince ? ` ${Math.round((Date.now() - busySince) / 1000)} с` : ""}
              </span>
            </div>
          </PanelSectionRow>
        )}
        {isBusy && busySince > 0 && Date.now() - busySince > 15000 && (
          <PanelSectionRow>
            <div style={{ fontSize: "11px", opacity: 0.7 }}>Долго? «⛔ Отключить» отменит подключение. Подробности — в «📜 Журнал».</div>
          </PanelSectionRow>
        )}
      </PanelSection>

      <SetupWarning setup={setup} />

      {/* 2. Локации и «Отключить» */}
      <PanelSection title="Локация">
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={isBusy}
            onClick={() => doAction("fastest", { key: "fastest", label: "Самая быстрая", ms: fastest?.ping ?? null })}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
              <span>⚡ Самая быстрая</span>
              {fastest ? (
                <span style={{ fontSize: "12px", opacity: 0.85 }}>
                  {flagOf(fastest.iso)} {labelOf(fastest, rows)} · <PingBadge ms={fastest.ping} />
                </span>
              ) : (
                <PingBadge ms={null} />
              )}
            </div>
          </ButtonItem>
        </PanelSectionRow>
        {LOCATIONS.map((loc) => {
          const key = fixedKey(loc.id);
          const active = key === activeKey;
          const live = livePingFixed(loc);
          const p = shownPing(key, live);
          return (
            <PanelSectionRow key={loc.id}>
              <ButtonItem
                layout="below"
                disabled={isBusy}
                onClick={() => doAction(loc.id, { key, label: loc.label, ms: live })}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
                  <span style={active ? { color: "#59bf40", fontWeight: "bold" } : undefined}>
                    {active ? "✅" : loc.flag} {loc.label}
                  </span>
                  <PingBadge ms={p.ms} frozen={p.frozen} />
                </div>
              </ButtonItem>
            </PanelSectionRow>
          );
        })}
        <PanelSectionRow>
          <ButtonItem layout="below" onClick={() => doAction("off")}>
            {isBusy ? "⛔ Отменить и отключить" : "⛔ Отключить"}
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <div style={{ fontSize: "11px", opacity: 0.6 }}>{pingNote}</div>
        </PanelSectionRow>
      </PanelSection>

      {/* 2а. Избранное — всегда над «Другими» */}
      {favRows.length > 0 && <PanelSection title="⭐ Избранное">{favRows.map(rowItem)}</PanelSection>}

      {/* 2б. Все остальные локации аккаунта */}
      <PanelSection title="Другие локации">
        <PanelSectionRow>
          <ToggleField
            label={`Показать другие (${restRows.length})`}
            description={
              locs?.source === "fallback"
                ? "Встроенный список плагина: CLI сейчас недоступен, пинга нет"
                : "☆ — добавить в избранное. Пинг виден сразу, до подключения."
            }
            checked={othersOpen}
            onChange={(v: boolean) => {
              setOthersOpen(v);
              if (v) loadLocations(); // свежий пинг при открытии (кеш бэкенда 45 сек.)
            }}
          />
        </PanelSectionRow>
        {othersOpen && restRows.map(rowItem)}
      </PanelSection>

      {/* 3. Настройки */}
      <SettingsSection options={autoOptions} onUpdated={() => setLogVer((v) => v + 1)} />

      {/* 4. Аккаунт */}
      <AccountSection
        onChanged={onAccountChanged}
        forceShow={status?.error === "not_logged_in"} />

      {/* 5. Дополнительно */}
      <PanelSection title="Дополнительно">
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={isBusy}
            onClick={() => {
              refresh();
              loadLocations(true);
              recheck();
              loadIp(true);
              setLogVer((v) => v + 1);
            }}
          >
            🔄 Обновить статус, пинг и IP
          </ButtonItem>
        </PanelSectionRow>
        <EventLog version={logVer} />
      </PanelSection>

      {/* Подпись автора — мелко, в самом низу */}
      <PanelSection>
        <PanelSectionRow>
          <div style={{ fontSize: "10px", opacity: 0.4, textAlign: "center", width: "100%" }}>
            by MaxFoley · сделано с помощью Grok Bot{pluginVer ? ` · v${pluginVer}` : ""}
          </div>
        </PanelSectionRow>
      </PanelSection>
    </>
  );
}

export default definePlugin(() => {
  // Уведомления от бэкенда (сторож, автоподключение) — работают и при закрытой панели
  const onToast = addEventListener<[title: string, body: string]>("adguard_toast", (title, body) => notify(title, body));
  return {
    name: "AdGuard VPN",
    titleView: <div className={staticClasses.Title}>AdGuard VPN</div>,
    content: <Content />,
    icon: <FaShieldAlt />,
    onDismount() {
      removeEventListener("adguard_toast", onToast); // VPN и запущенные скрипты не трогаем
    },
  };
});
